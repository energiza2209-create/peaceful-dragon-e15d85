/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Sparkles, Target, Store, Plus, Lightbulb, 
  Trash2, ArrowUpRight, HelpCircle, UserCheck 
} from 'lucide-react';
import { Insight, InsightCategory, User } from '../types';

interface InsightsProps {
  insights: Insight[];
  onAddInsight: (title: string, description: string, category: InsightCategory, createdBy: string) => void;
  onDeleteInsight: (id: string) => void;
  onConvertToQuote: (insight: Insight) => void;
  users: User[];
  activeUserId: string;
}

export default function InsightsModule({
  insights,
  onAddInsight,
  onDeleteInsight,
  onConvertToQuote,
  users,
  activeUserId,
}: InsightsProps) {
  // Filters state
  const [filterCategory, setFilterCategory] = useState<InsightCategory | 'all'>('all');

  // Form state
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<InsightCategory>('nicho');
  const [authorId, setAuthorId] = useState(activeUserId);

  const activeUser = users.find(u => u.id === activeUserId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) return;

    const selectedUser = users.find(u => u.id === authorId) || activeUser;
    onAddInsight(title.trim(), description.trim(), category, selectedUser?.name || 'Sistema');
    
    // Clear inputs
    setTitle('');
    setDescription('');
  };

  const getCategoryTheme = (cat: InsightCategory) => {
    switch (cat) {
      case 'nicho':
        return {
          bg: 'bg-indigo-50 dark:bg-indigo-950/40',
          border: 'border-indigo-100 dark:border-indigo-800',
          text: 'text-indigo-700 dark:text-indigo-400',
          icon: Target,
          label: 'Nicho de Mercado',
        };
      case 'supplier':
        return {
          bg: 'bg-emerald-50 dark:bg-emerald-950/40',
          border: 'border-emerald-100 dark:border-emerald-800',
          text: 'text-emerald-700 dark:text-emerald-400',
          icon: Store,
          label: 'Fornecedor',
        };
      case 'improvement':
        return {
          bg: 'bg-amber-50 dark:bg-amber-950/40',
          border: 'border-amber-100 dark:border-amber-800',
          text: 'text-amber-700 dark:text-amber-400',
          icon: Lightbulb,
          label: 'Melhoria de Processo',
        };
      default:
        return {
          bg: 'bg-zinc-100 dark:bg-zinc-800',
          border: 'border-zinc-200 dark:border-zinc-750',
          text: 'text-zinc-700 dark:text-zinc-300',
          icon: HelpCircle,
          label: 'Ideia Geral',
        };
    }
  };

  // Filtered list
  const filteredInsights = filterCategory === 'all'
    ? insights
    : insights.filter(i => i.category === filterCategory);

  return (
    <div id="insights-board" className="grid grid-cols-1 lg:grid-cols-12 gap-6 text-left">
      
      {/* Left Column: Register Idea Form (Span 4) */}
      <div className="lg:col-span-4">
        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-5 shadow-xs sticky top-4">
          <div className="flex items-center gap-2 mb-4">
            <Sparkles className="w-5 h-5 text-indigo-500" />
            <h3 className="font-bold text-zinc-900 dark:text-white">Registrar Insight</h3>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-zinc-500 dark:text-zinc-400 block">Título do Insight / Oportunidade:</label>
              <input
                id="input-insight-title"
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Ex: Novo fabricante de cabos elétricos"
                className="w-full text-sm bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg p-2.5 text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-zinc-500 dark:text-zinc-400 block">Categoria:</label>
              <div className="grid grid-cols-3 gap-2">
                {([
                  { key: 'nicho', label: '🎯 Nicho' },
                  { key: 'supplier', label: '🏪 Fornec.' },
                  { key: 'improvement', label: '💡 Melhoria' }
                ] as const).map((catItem) => (
                  <button
                    key={catItem.key}
                    id={`btn-insight-category-${catItem.key}`}
                    type="button"
                    onClick={() => setCategory(catItem.key)}
                    className={`text-xs p-2 rounded-lg border transition-all truncate text-center ${
                      category === catItem.key
                        ? 'bg-indigo-600 border-indigo-600 text-white font-semibold'
                        : 'bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-750 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-50 dark:hover:bg-zinc-800'
                    }`}
                  >
                    {catItem.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-zinc-500 dark:text-zinc-400 block">Especificação ou Detalhes importantes:</label>
              <textarea
                id="textarea-insight-description"
                rows={4}
                required
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Ex: Achei o link deles no MercadoLivre. Preço de atacado em rolos de 100m. Chamar no Whatsapp após as 14h."
                className="w-full text-sm bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg p-2.5 text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 resize-none h-24"
              />
            </div>

            {/* Author Quickswitch inside form */}
            <div className="space-y-1 pt-1">
              <label className="text-xs font-semibold text-zinc-500 dark:text-zinc-400 block flex items-center gap-1">
                <UserCheck className="w-3.5 h-3.5" />
                Registrado por:
              </label>
              <div className="flex bg-zinc-100 dark:bg-zinc-800 p-0.5 rounded-lg text-xs">
                {users.map((u) => (
                  <button
                    key={u.id}
                    id={`btn-insight-author-${u.id}`}
                    type="button"
                    onClick={() => setAuthorId(u.id)}
                    className={`flex-1 px-3 py-1.5 rounded-md transition-all font-medium ${
                      authorId === u.id
                        ? 'bg-white dark:bg-zinc-700 text-zinc-800 dark:text-white shadow-xs'
                        : 'text-zinc-500 dark:text-zinc-400 hover:text-zinc-700'
                    }`}
                  >
                    {u.role === 'eu' ? 'Eu 🙋‍♂️' : `${u.name} 🙋‍♀️`}
                  </button>
                ))}
              </div>
            </div>

            <button
              id="btn-register-insight"
              type="submit"
              className="w-full bg-indigo-650 hover:bg-indigo-600 active:bg-indigo-750 text-white font-semibold text-sm py-2.5 rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer mt-2"
            >
              <Plus className="w-4 h-4" />
              Salvar Ideia no Inbox
            </button>
          </form>
        </div>
      </div>

      {/* Right Column: List & Category filters (Span 8) */}
      <div className="lg:col-span-8 space-y-4">
        
        {/* Category Filters row */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none border-b border-zinc-100 dark:border-zinc-800">
          {([
            { id: 'all', label: '🗂 Todos Insights' },
            { id: 'nicho', label: '🎯 Novos Nichos' },
            { id: 'supplier', label: '🏪 Fornecedores' },
            { id: 'improvement', label: '💡 Melhorias' }
          ] as const).map((filter) => (
            <button
              key={filter.id}
              id={`btn-filter-insight-${filter.id}`}
              onClick={() => setFilterCategory(filter.id)}
              className={`text-xs px-4 py-2 font-semibold rounded-lg shrink-0 transition-colors ${
                filterCategory === filter.id
                  ? 'bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900'
                  : 'bg-white dark:bg-zinc-900 text-zinc-600 dark:text-zinc-400 hover:bg-zinc-50 dark:hover:bg-zinc-800 border border-zinc-200 dark:border-zinc-800'
              }`}
            >
              {filter.label}
            </button>
          ))}
        </div>

        {/* Dynamic Cards list */}
        {filteredInsights.length === 0 ? (
          <div className="text-center py-20 bg-white dark:bg-zinc-900 rounded-2xl border border-dashed border-zinc-200 dark:border-zinc-800/80 flex flex-col items-center justify-center gap-3">
            <Lightbulb className="w-10 h-10 text-zinc-300 dark:text-zinc-600" />
            <div>
              <p className="text-sm font-bold text-zinc-800 dark:text-zinc-200">Inbox de Ideias Vazio</p>
              <p className="text-xs text-zinc-450 mt-1 max-w-[320px] mx-auto leading-relaxed">
                Nenhum insight cadastrado para essa categoria. Use a ficha à esquerda para registrar!
              </p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredInsights.map((ins) => {
              const theme = getCategoryTheme(ins.category);
              const CategoryIcon = theme.icon;

              return (
                <div 
                  key={ins.id}
                  id={`insight-item-${ins.id}`}
                  className="bg-white dark:bg-zinc-900 rounded-xl border border-zinc-250 dark:border-zinc-800 p-5 shadow-xs hover:shadow-xs transition-all flex flex-col justify-between"
                >
                  <div>
                    {/* Top indicator tag */}
                    <div className="flex items-center justify-between gap-2 mb-3">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[10px] font-extrabold ${theme.bg} ${theme.text}`}>
                        <CategoryIcon className="w-3 h-3" />
                        {theme.label}
                      </span>
                      
                      <div className="flex items-center gap-1">
                        <span className="text-[10px] text-zinc-400 dark:text-zinc-400">
                          Por: <strong>{ins.createdBy}</strong>
                        </span>
                        
                        {/* Quick Trash delete button */}
                        <button
                          id={`btn-delete-insight-${ins.id}`}
                          onClick={() => onDeleteInsight(ins.id)}
                          className="text-zinc-400 hover:text-rose-500 p-1 rounded-sm transition-colors cursor-pointer"
                          title="Deletar ideia"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <h4 className="text-sm font-bold text-zinc-900 dark:text-white mb-2 leading-tight">
                      {ins.title}
                    </h4>

                    <p className="text-xs text-zinc-600 dark:text-zinc-300 leading-relaxed whitespace-pre-wrap mb-4 line-clamp-4">
                      {ins.description}
                    </p>
                  </div>

                  {/* Operational Bottom bar: Converted check / Converter em Cotação */}
                  <div className="border-t border-zinc-100 dark:border-zinc-800/80 pt-3 flex items-center justify-between text-[11px]">
                    <span className="text-zinc-400">
                      Cadastrado em: {new Date(ins.createdAt).toLocaleDateString('pt-BR')}
                    </span>

                    {ins.convertedToQuoteId ? (
                      <span className="text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
                        ✓ Convertido em Obra
                      </span>
                    ) : (
                      <button
                        id={`btn-convert-insight-${ins.id}`}
                        onClick={() => onConvertToQuote(ins)}
                        className="bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/20 dark:hover:bg-indigo-950/40 text-indigo-700 dark:text-indigo-400 font-bold px-3 py-1.5 rounded-lg flex items-center gap-1 border border-indigo-150 dark:border-indigo-900/30 transition-colors cursor-pointer"
                      >
                        <ArrowUpRight className="w-3.5 h-3.5" />
                        Gerar Cotação
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

      </div>

    </div>
  );
}
