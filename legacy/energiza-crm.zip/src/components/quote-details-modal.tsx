/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  X, Calendar, Phone, Mail, DollarSign, Percent, 
  User, ShieldAlert, FileText, CheckCircle, Clock, 
  Trash2, AlertTriangle, MessageSquare, Edit3, ArrowRight
} from 'lucide-react';
import { Quote, User as CRMUser, FeedbackLog, QuoteStatus, Priority } from '../types';
import FeedbackTimeline from './feedback-timeline';

interface QuoteDetailsModalProps {
  quote: Quote;
  onClose: () => void;
  onUpdateQuote: (updatedQuote: Quote) => void;
  onDeleteQuote: (id: string) => void;
  feedbacks: FeedbackLog[];
  onAddFeedback: (quoteId: string, note: string, createdBy: string) => void;
  onDeleteFeedback: (id: string) => void;
  users: CRMUser[];
  activeUserId: string;
}

export default function QuoteDetailsModal({
  quote,
  onClose,
  onUpdateQuote,
  onDeleteQuote,
  feedbacks,
  onAddFeedback,
  onDeleteFeedback,
  users,
  activeUserId,
}: QuoteDetailsModalProps) {
  const [isEditing, setIsEditing] = useState(false);

  // Form Fields
  const [clientName, setClientName] = useState(quote.clientName);
  const [projectName, setProjectName] = useState(quote.projectName);
  const [contactPhone, setContactPhone] = useState(quote.contactPhone);
  const [contactEmail, setContactEmail] = useState(quote.contactEmail);
  const [description, setDescription] = useState(quote.description);
  const [value, setValue] = useState(quote.value);
  const [margin, setMargin] = useState(quote.margin);
  const [estimatedDate, setEstimatedDate] = useState(quote.estimatedDate);
  const [priority, setPriority] = useState<Priority>(quote.priority);
  const [responsibleId, setResponsibleId] = useState(quote.responsibleId);
  const [status, setStatus] = useState<QuoteStatus>(quote.status);

  // Loss States
  const [lossReason, setLossReason] = useState<Quote['lossReason']>(quote.lossReason || 'price');
  const [lossDetails, setLossDetails] = useState(quote.lossDetails || '');

  // Delete Confirmation State
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);

  // Keep fields synchronized if quote prop changes
  useEffect(() => {
    setClientName(quote.clientName);
    setProjectName(quote.projectName);
    setContactPhone(quote.contactPhone);
    setContactEmail(quote.contactEmail);
    setDescription(quote.description);
    setValue(quote.value);
    setMargin(quote.margin);
    setEstimatedDate(quote.estimatedDate);
    setPriority(quote.priority);
    setResponsibleId(quote.responsibleId);
    setStatus(quote.status);
    setLossReason(quote.lossReason || 'price');
    setLossDetails(quote.lossDetails || '');
    setShowConfirmDelete(false);
  }, [quote]);

  const handleSaveBasic = () => {
    const updated: Quote = {
      ...quote,
      clientName,
      projectName,
      contactPhone,
      contactEmail,
      description,
      value: Number(value),
      margin: Number(margin),
      estimatedDate,
      priority,
      responsibleId,
      status,
      lossReason: status === 'lost' ? lossReason : undefined,
      lossDetails: status === 'lost' ? lossDetails : undefined,
      updatedAt: new Date().toISOString(),
    };
    onUpdateQuote(updated);
    setIsEditing(false);
  };

  const handleQuickStatusChange = (newStatus: QuoteStatus) => {
    setStatus(newStatus);
    
    // Auto-save unless it's moving to lost (which requires reason filling first!)
    if (newStatus !== 'lost') {
      const updated: Quote = {
        ...quote,
        status: newStatus,
        lossReason: undefined,
        lossDetails: undefined,
        updatedAt: new Date().toISOString(),
      };
      onUpdateQuote(updated);
      
      // Auto-log system feedback
      const responsibleName = users.find(u => u.id === activeUserId)?.name || 'Sistema';
      const statusLabels: Record<QuoteStatus, string> = {
        new: 'Nova / Triagem',
        analysis: 'Em Elaboração',
        sent: 'Enviada ao Cliente',
        negotiation: 'Negociação',
        won: 'Ganhada 🎉',
        lost: 'Perdida ❌',
      };
      onAddFeedback(quote.id, `Status alterado para "${statusLabels[newStatus]}"`, 'Sistema');
    }
  };

  // Confirm and save the loss details
  const handleConfirmLoss = () => {
    const updated: Quote = {
      ...quote,
      status: 'lost',
      lossReason,
      lossDetails,
      updatedAt: new Date().toISOString(),
    };
    onUpdateQuote(updated);
    
    const reasonLabels = {
      price: 'Preço Alto',
      deadline: 'Prazo Longo',
      competitor: 'Fator Concorrência',
      vanished: 'Cliente Sumiu (Sem Resposta)',
      other: 'Outro Motivo',
    };
    
    onAddFeedback(
      quote.id, 
      `Cotação marcada como PERDIDA. Motivo: ${reasonLabels[lossReason || 'price']}.\nDetalhes: ${lossDetails || 'Nenhum detalhe adicional informado.'}`, 
      'Sistema'
    );
  };

  const currentFeedbacks = feedbacks.filter(f => f.quoteId === quote.id);

  // Calculate WhatsApp link
  const cleanPhone = contactPhone.replace(/\D/g, '');
  const waLink = cleanPhone ? `https://wa.me/${cleanPhone.startsWith('55') ? cleanPhone : '55' + cleanPhone}` : null;

  return (
    <div id="modal-backdrop" className="fixed inset-0 z-50 overflow-y-auto bg-zinc-950/60 backdrop-blur-xs flex items-center justify-center p-4">
      {/* Modal Card */}
      <div className="bg-white dark:bg-zinc-900 w-full max-w-4xl rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-zinc-100 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-950 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className={`w-3 h-3 rounded-full ${
              quote.status === 'won' ? 'bg-emerald-500' :
              quote.status === 'lost' ? 'bg-rose-500' :
              quote.status === 'negotiation' ? 'bg-amber-500' :
              quote.status === 'sent' ? 'bg-blue-500' :
              quote.status === 'analysis' ? 'bg-indigo-500' :
              'bg-zinc-500'
            }`} />
            <div>
              <p className="text-xs font-mono text-zinc-400 dark:text-zinc-500">
                PROJETO / COTAÇÃO ID: {quote.id.substring(0, 8).toUpperCase()}
              </p>
              <h3 className="text-lg font-bold text-zinc-900 dark:text-white leading-tight">
                {quote.projectName || 'Sem Nome de Projeto'}
              </h3>
            </div>
          </div>
          
          <button
            id="btn-close-modal"
            onClick={onClose}
            className="text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 p-1.5 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body (Scrollable Split-Screen on Desktop) */}
        <div className="flex-1 overflow-y-auto grid grid-cols-1 lg:grid-cols-12 divide-y lg:divide-y-0 lg:divide-x divide-zinc-200 dark:divide-zinc-800">
          
          {/* Left Side: General Profile & Details (Span 7) */}
          <div className="lg:col-span-7 p-6 space-y-6">
            
            {/* Quick Status Control Row */}
            <div className="flex flex-wrap items-center justify-between gap-3 bg-zinc-50 dark:bg-zinc-800/20 p-3 rounded-xl border border-zinc-100 dark:border-zinc-800">
              <span className="text-xs font-semibold text-zinc-500 dark:text-zinc-400">Status Funil:</span>
              <div className="flex gap-1 overflow-x-auto max-w-full pb-1 sm:pb-0 scrollbar-none">
                {(['new', 'analysis', 'sent', 'negotiation', 'won', 'lost'] as QuoteStatus[]).map((st) => {
                  const labels: Record<QuoteStatus, string> = {
                    new: 'Nova',
                    analysis: 'Elaboração',
                    sent: 'Enviada',
                    negotiation: 'Ajustes',
                    won: 'Ganha ✔',
                    lost: 'Perdida ✘',
                  };
                  return (
                    <button
                      key={st}
                      id={`btn-modal-status-${st}`}
                      onClick={() => handleQuickStatusChange(st)}
                      className={`text-xs px-2.5 py-1 rounded-md font-medium transition-all cursor-pointer ${
                        status === st
                          ? st === 'won' ? 'bg-emerald-500 text-white shadow-xs' :
                            st === 'lost' ? 'bg-rose-500 text-white shadow-xs' :
                            st === 'negotiation' ? 'bg-amber-500 text-white shadow-xs' :
                            st === 'sent' ? 'bg-blue-500 text-white shadow-xs' :
                            st === 'analysis' ? 'bg-indigo-500 text-white shadow-xs' :
                            'bg-zinc-700 text-white shadow-xs'
                          : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 hover:text-zinc-800 dark:hover:text-zinc-200'
                      }`}
                    >
                      {labels[st]}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* GATE OF LOSS: Required input for status 'lost' */}
            {status === 'lost' && (
              <div className="bg-rose-50 dark:bg-rose-950/30 p-4 rounded-xl border border-rose-150 dark:border-rose-900/60 space-y-3">
                <div className="flex items-start gap-2.5">
                  <ShieldAlert className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-sm font-bold text-rose-800 dark:text-rose-300">Detalhamento de Perda Exigido</h4>
                    <p className="text-xs text-rose-600 dark:text-rose-400 mt-0.5">
                      Para análise histórica, defina o principal fator do declínio e registre os detalhes.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {([
                    { key: 'price', label: '💸 Preço Alto' },
                    { key: 'deadline', label: '⏱ Prazo Longo' },
                    { key: 'competitor', label: '⚔ Concorrência' },
                    { key: 'vanished', label: '👻 Cliente Sumiu' },
                    { key: 'other', label: '⚙ Outros' }
                  ] as const).map((r) => (
                    <button
                      key={r.key}
                      id={`btn-loss-reason-${r.key}`}
                      type="button"
                      onClick={() => setLossReason(r.key)}
                      className={`text-xs p-2 rounded-lg border text-left transition-all ${
                        lossReason === r.key
                          ? 'bg-rose-600 border-rose-600 text-white font-semibold'
                          : 'bg-white dark:bg-zinc-900 border-rose-200 dark:border-rose-900/40 text-rose-700 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/20'
                      }`}
                    >
                      {r.label}
                    </button>
                  ))}
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-medium text-rose-700 dark:text-rose-400 block">Detalhamento / feedback sincero:</label>
                  <input
                    id="input-loss-details"
                    type="text"
                    value={lossDetails}
                    onChange={(e) => setLossDetails(e.target.value)}
                    placeholder="Ex: Concorrente cobrou mais barato ou cliente desistiu da obra."
                    className="w-full text-xs p-2.5 rounded-lg bg-white dark:bg-zinc-900 border border-rose-200 dark:border-rose-900/50 text-zinc-900 dark:text-white placeholder-rose-300 focus:outline-hidden focus:ring-1 focus:ring-rose-500"
                  />
                </div>

                <div className="flex justify-end pt-1">
                  <button
                    id="btn-confirm-loss"
                    type="button"
                    onClick={handleConfirmLoss}
                    className="bg-rose-600 hover:bg-rose-700 active:bg-rose-800 text-xs text-white font-semibold px-3 py-1.5 rounded-lg flex items-center gap-1 transition-colors cursor-pointer"
                  >
                    Confirmar Motivo de Perda
                  </button>
                </div>
              </div>
            )}

            {/* Display / Edit details container */}
            <div className="bg-zinc-50 dark:bg-zinc-800/10 p-5 rounded-xl border border-zinc-200/60 dark:border-zinc-800/80">
              <div className="flex items-center justify-between mb-4 border-b border-zinc-200 dark:border-zinc-800 pb-2">
                <span className="text-sm font-bold text-zinc-800 dark:text-zinc-200 flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-indigo-500" />
                  Informações Fiscais e Comerciais
                </span>
                <button
                  id="btn-toggle-edit"
                  onClick={() => setIsEditing(!isEditing)}
                  className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  {isEditing ? 'Cancelar Edição' : 'Editar Detalhes'}
                </button>
              </div>

              {isEditing ? (
                /* EDIT FORM STATE */
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-zinc-500 dark:text-zinc-400 block">Nome do Cliente:</label>
                      <input
                        id="form-client-name"
                        type="text"
                        value={clientName}
                        onChange={(e) => setClientName(e.target.value)}
                        className="w-full text-sm bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg p-2.5 text-zinc-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-zinc-500 dark:text-zinc-400 block">Nome do Projeto:</label>
                      <input
                        id="form-project-name"
                        type="text"
                        value={projectName}
                        onChange={(e) => setProjectName(e.target.value)}
                        className="w-full text-sm bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg p-2.5 text-zinc-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-zinc-500 dark:text-zinc-400 block">WhatsApp / Telefone:</label>
                      <input
                        id="form-phone"
                        type="text"
                        value={contactPhone}
                        onChange={(e) => setContactPhone(e.target.value)}
                        className="w-full text-sm bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg p-2.5 text-zinc-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-zinc-500 dark:text-zinc-400 block">E-mail do Cliente:</label>
                      <input
                        id="form-email"
                        type="email"
                        value={contactEmail}
                        onChange={(e) => setContactEmail(e.target.value)}
                        className="w-full text-sm bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg p-2.5 text-zinc-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-zinc-500 dark:text-zinc-400 block">Descrição e Escopo do Pedido:</label>
                    <textarea
                      id="form-description"
                      rows={3}
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      className="w-full text-sm bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg p-2.5 text-zinc-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 resize-none"
                    />
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-zinc-500 dark:text-zinc-400 block">Valor Estimado (R$):</label>
                      <input
                        id="form-value"
                        type="number"
                        value={value}
                        onChange={(e) => setValue(Number(e.target.value))}
                        className="w-full text-sm bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg p-2.5 text-zinc-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-zinc-500 dark:text-zinc-400 block">Margem Lucro (%):</label>
                      <input
                        id="form-margin"
                        type="number"
                        value={margin}
                        onChange={(e) => setMargin(Number(e.target.value))}
                        className="w-full text-sm bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg p-2.5 text-zinc-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-zinc-500 dark:text-zinc-400 block">Prazo de Entrega:</label>
                      <input
                        id="form-estimated-date"
                        type="date"
                        value={estimatedDate}
                        onChange={(e) => setEstimatedDate(e.target.value)}
                        className="w-full text-sm bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg p-2.5 text-zinc-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-zinc-500 dark:text-zinc-400 block">Responsável ID:</label>
                      <select
                        id="form-responsible"
                        value={responsibleId}
                        onChange={(e) => setResponsibleId(e.target.value)}
                        className="w-full text-sm bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg p-2.5 text-zinc-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20"
                      >
                        {users.map(u => (
                          <option key={u.id} value={u.id}>{u.name}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      id="btn-cancel-edit"
                      onClick={() => setIsEditing(false)}
                      type="button"
                      className="px-4 py-2 border border-zinc-200 dark:border-zinc-700 rounded-lg text-sm font-medium text-zinc-600 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors cursor-pointer"
                    >
                      Voltar
                    </button>
                    <button
                      id="btn-save-edit"
                      onClick={handleSaveBasic}
                      type="button"
                      className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-sm font-medium text-white rounded-lg transition-colors cursor-pointer"
                    >
                      Salvar Alterações
                    </button>
                  </div>
                </div>
              ) : (
                /* READ-ONLY STATE */
                <div className="space-y-4">
                  {/* Two-column values */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4">
                    
                    <div className="flex items-start gap-2.5">
                      <User className="w-4 h-4 text-zinc-400 mt-0.5 shrink-0" />
                      <div>
                        <span className="text-[10px] font-bold text-zinc-400 uppercase">Cliente</span>
                        <p className="text-sm font-bold text-zinc-800 dark:text-zinc-100">{quote.clientName}</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <User className="w-4 h-4 text-zinc-400 mt-0.5 shrink-0" />
                      <div>
                        <span className="text-[10px] font-bold text-zinc-400 uppercase">Responsável</span>
                        <p className="text-sm font-medium text-zinc-800 dark:text-zinc-100">
                          {users.find(u => u.id === quote.responsibleId)?.name || 'Não atribuído'}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <Phone className="w-4 h-4 text-zinc-400 mt-0.5 shrink-0" />
                      <div>
                        <span className="text-[10px] font-bold text-zinc-400 uppercase block">WhatsApp / Canal</span>
                        {waLink ? (
                          <a
                            id="link-wa"
                            href={waLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm font-semibold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1 mt-0.5"
                          >
                            {quote.contactPhone}
                            <ArrowRight className="w-3.5 h-3.5" />
                          </a>
                        ) : (
                          <p className="text-sm text-zinc-800 dark:text-zinc-100">{quote.contactPhone || 'Sem telefone'}</p>
                        )}
                      </div>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <Mail className="w-4 h-4 text-zinc-400 mt-0.5 shrink-0" />
                      <div>
                        <span className="text-[10px] font-bold text-zinc-400 uppercase">E-mail</span>
                        {quote.contactEmail ? (
                          <a
                            id="link-email"
                            href={`mailto:${quote.contactEmail}`}
                            className="text-sm text-zinc-800 dark:text-zinc-200 hover:underline block"
                          >
                            {quote.contactEmail}
                          </a>
                        ) : (
                          <p className="text-sm text-zinc-400">Sem e-mail cadastrado</p>
                        )}
                      </div>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <DollarSign className="w-4 h-4 text-zinc-400 mt-0.5 shrink-0" />
                      <div>
                        <span className="text-[10px] font-bold text-zinc-400 uppercase">Valor do Projeto</span>
                        <p className="text-base font-extrabold text-zinc-900 dark:text-white">
                          {quote.value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <Percent className="w-4 h-4 text-zinc-400 mt-0.5 shrink-0" />
                      <div>
                        <span className="text-[10px] font-bold text-zinc-400 uppercase">Ganhos Estimados (Margem {quote.margin}%)</span>
                        <p className="text-sm font-bold text-emerald-600 dark:text-emerald-400">
                          {((quote.value * quote.margin) / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <Calendar className="w-4 h-4 text-zinc-400 mt-0.5 shrink-0" />
                      <div>
                        <span className="text-[10px] font-bold text-zinc-400 uppercase">Prazo / Entrega</span>
                        <p className="text-sm font-semibold text-zinc-800 dark:text-zinc-200">
                          {quote.estimatedDate
                            ? new Date(quote.estimatedDate + 'T00:00:00').toLocaleDateString('pt-BR')
                            : 'A definir'}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <Clock className="w-4 h-4 text-zinc-400 mt-0.5 shrink-0" />
                      <div>
                        <span className="text-[10px] font-bold text-zinc-400 uppercase">Criação</span>
                        <p className="text-xs text-zinc-600 dark:text-zinc-400">
                          {new Date(quote.createdAt).toLocaleDateString('pt-BR')} às {new Date(quote.createdAt).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      </div>
                    </div>

                  </div>

                  {/* Description Box */}
                  <div className="border-t border-zinc-200 dark:border-zinc-800 pt-3 mt-4">
                    <span className="text-[10px] font-bold text-zinc-400 uppercase block mb-1">Descrição e Especificação</span>
                    <div className="bg-white dark:bg-zinc-900 border border-zinc-150 dark:border-zinc-800/80 p-3 rounded-lg text-sm text-zinc-600 dark:text-zinc-300 leading-relaxed whitespace-pre-wrap">
                      {quote.description || 'Nenhuma especificação gravada para esta cotação.'}
                    </div>
                  </div>

                  {/* Loss Factor display if lost and confirmed */}
                  {quote.status === 'lost' && quote.lossReason && (
                    <div className="bg-rose-50 dark:bg-rose-950/20 border border-rose-100 dark:border-rose-900/40 p-4 rounded-xl flex items-start gap-3 mt-2">
                      <AlertTriangle className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
                      <div>
                        <p className="text-xs font-bold text-rose-800 dark:text-rose-300">
                          Razão Declínio:{' '}
                          <span className="underline">
                            {quote.lossReason === 'price' ? 'Preço Alto' :
                             quote.lossReason === 'deadline' ? 'Prazo Estendido' :
                             quote.lossReason === 'competitor' ? 'Concorrência Directa' :
                             quote.lossReason === 'vanished' ? 'Sumiço de Contato' : 'Outros'}
                          </span>
                        </p>
                        <p className="text-xs text-rose-600 dark:text-rose-400 mt-1 italic">
                          "{quote.lossDetails || 'Sem comentários adicionais.'}"
                        </p>
                      </div>
                    </div>
                  )}

                </div>
              )}
            </div>

            {/* Quick delete feature with safe in-app double-confirmation */}
            <div className="pt-6 border-t border-zinc-100 dark:border-zinc-800 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div className="max-w-[280px]">
                <p className="text-[10px] text-zinc-400">
                  {showConfirmDelete 
                    ? 'Atenção: Esta ação é irreversível e excluirá todo o histórico de negociação da cotação!'
                    : 'Para excluir fisicamente este registro de consulta, utilize o botão ao lado:'
                  }
                </p>
              </div>
              
              {showConfirmDelete ? (
                <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                  <button
                    id="btn-confirm-delete-no"
                    onClick={() => setShowConfirmDelete(false)}
                    className="px-3 py-1.5 rounded-xl border border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 text-xs font-semibold cursor-pointer transition-all"
                  >
                    Cancelar
                  </button>
                  <button
                    id="btn-confirm-delete-yes"
                    onClick={() => onDeleteQuote(quote.id)}
                    className="bg-rose-600 hover:bg-rose-700 text-white px-3.5 py-1.5 rounded-xl flex items-center gap-1 text-xs font-bold cursor-pointer transition-all shadow-xs"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Sim, Excluir
                  </button>
                </div>
              ) : (
                <button
                  id="btn-delete-quote"
                  onClick={() => setShowConfirmDelete(true)}
                  className="bg-zinc-50 hover:bg-rose-50/50 dark:bg-zinc-800/40 dark:hover:bg-rose-950/20 text-zinc-400 hover:text-rose-600 dark:hover:text-rose-400 p-2 rounded-xl border border-zinc-200 dark:border-zinc-800 hover:border-rose-100 dark:hover:border-rose-900/40 flex items-center gap-1.5 text-xs transition-all font-semibold cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                  Excluir Cotação
                </button>
              )}
            </div>

          </div>

          {/* Right Side: Timeline & Logs (Span 5) */}
          <div className="lg:col-span-5 p-6 bg-zinc-50/50 dark:bg-zinc-900/40 flex flex-col max-h-full">
            <h4 className="text-sm font-bold text-zinc-800 dark:text-zinc-200 flex items-center gap-1.5 border-b border-zinc-200 dark:border-zinc-800 pb-3 mb-4">
              <MessageSquare className="w-4 h-4 text-indigo-500" />
              Timeline de Negociações ({currentFeedbacks.length})
            </h4>
            
            <div className="flex-1 overflow-y-auto pr-1">
              <FeedbackTimeline
                feedbacks={currentFeedbacks}
                onAddFeedback={(note, createdBy) => onAddFeedback(quote.id, note, createdBy)}
                onDeleteFeedback={onDeleteFeedback}
                users={users}
                activeUserId={activeUserId}
              />
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
