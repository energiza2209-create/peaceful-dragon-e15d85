/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Database, FileCode, FolderTree, Copy, Check, 
  Cloud, CloudLightning, ShieldAlert, KeyRound, Play,
  RefreshCw, CheckCircle2, AlertTriangle, ArrowUpRight, ArrowDownLeft
} from 'lucide-react';
import { Quote, FeedbackLog, Insight } from '../types';
import { 
  getSupabaseConfig, 
  saveSupabaseConfig, 
  clearSupabaseConfig, 
  testSupabaseConnection, 
  syncDataToSupabase, 
  pullDataFromSupabase 
} from '../lib/supabase';

interface DatabaseSchemaProps {
  quotes: Quote[];
  feedbacks: FeedbackLog[];
  insights: Insight[];
  onReloadAllData: (quotes: Quote[], feedbacks: FeedbackLog[], insights: Insight[]) => void;
}

export default function DatabaseSchema({ quotes, feedbacks, insights, onReloadAllData }: DatabaseSchemaProps) {
  const [activeTab, setActiveTab] = useState<'prisma' | 'sql' | 'folders' | 'supabase'>('supabase');
  const [copied, setCopied] = useState(false);

  // Supabase input states
  const [supabaseUrl, setSupabaseUrl] = useState('');
  const [supabaseKey, setSupabaseKey] = useState('');
  
  // Progress & Alert states
  const [statusMsg, setStatusMsg] = useState<{ type: 'idle' | 'success' | 'error' | 'loading'; text: string }>({ type: 'idle', text: '' });
  const [isConnected, setIsConnected] = useState(false);

  // Synchronizer states
  const [syncStatus, setSyncStatus] = useState<{ type: 'idle' | 'success' | 'error' | 'syncing'; text: string }>({ type: 'idle', text: '' });

  // Load configuration on mount
  useEffect(() => {
    const config = getSupabaseConfig();
    if (config) {
      setSupabaseUrl(config.url);
      setSupabaseKey(config.anonKey);
      setIsConnected(true);
      setStatusMsg({ type: 'success', text: 'Configurações de credenciais locais carregadas!' });
    }
  }, []);

  const handleSaveConfig = () => {
    if (!supabaseUrl || !supabaseKey) {
      setStatusMsg({ type: 'error', text: 'Preencha a URL do projeto e a Chave de API anônima!' });
      return;
    }
    saveSupabaseConfig(supabaseUrl, supabaseKey);
    setIsConnected(true);
    setStatusMsg({ type: 'success', text: 'Credenciais salvas com sucesso no navegador!' });
  };

  const handleClearConfig = () => {
    clearSupabaseConfig();
    setSupabaseUrl('');
    setSupabaseKey('');
    setIsConnected(false);
    setStatusMsg({ type: 'idle', text: 'Credenciais limpas.' });
  };

  const handleTestConnection = async () => {
    if (!supabaseUrl || !supabaseKey) {
      setStatusMsg({ type: 'error', text: 'URL ou Chave faltando para testar.' });
      return;
    }
    
    setStatusMsg({ type: 'loading', text: 'Verificando conexão com o servidor Supabase...' });
    const res = await testSupabaseConnection(supabaseUrl, supabaseKey);
    
    if (res.success) {
      setIsConnected(true);
      setStatusMsg({ type: 'success', text: '🟢 Conexão Estabelecida com Sucesso! Suas chaves são válidas!' });
    } else {
      setIsConnected(false);
      setStatusMsg({ type: 'error', text: `🔴 Falha na Conexão: ${res.message}. Verifique as chaves e CORS no Supabase.` });
    }
  };

  const handlePushSync = async () => {
    if (!isConnected) {
      setSyncStatus({ type: 'error', text: 'Salve as credenciais e garanta uma conexão ativa antes de sincronizar.' });
      return;
    }
    
    setSyncStatus({ type: 'syncing', text: 'Enviando contêineres locais para a nuvem Supabase...' });
    const res = await syncDataToSupabase(quotes, feedbacks, insights);

    if (res.success) {
      setSyncStatus({ type: 'success', text: `✅ Sincronização concluída! ${res.quoteCount} cotações, ${res.feedbackCount} feedbacks e ${res.insightCount} ideias enviadas com sucesso.` });
    } else {
      setSyncStatus({ type: 'error', text: `❌ Falhou: ${res.message}. Certifique-se de executar o DDL SQL abaixo nas tabelas do Supabase.` });
    }
  };

  const handlePullSync = async () => {
    if (!isConnected) {
      setSyncStatus({ type: 'error', text: 'Defina e ative sua URL/Key do Supabase primeiro.' });
      return;
    }

    if (!window.confirm('Atenção: Carregar os dados da nuvem irá sobrescrever sua memória local atual. Deseja prosseguir?')) {
      return;
    }

    setSyncStatus({ type: 'syncing', text: 'Baixando conjuntos de dados ativos do Supabase...' });
    const res = await pullDataFromSupabase();

    if (res.success) {
      onReloadAllData(res.quotes, res.feedbacks, res.insights);
      setSyncStatus({ type: 'success', text: `✅ Sucesso! Sincronizado e substituído. Encontrados no banco: ${res.quotes.length} cotações, ${res.feedbacks.length} feedbacks.` });
    } else {
      setSyncStatus({ type: 'error', text: `❌ Erro no download dos dados: ${res.message}. Certifique-se de que as tabelas possuem permissões públicas ou as tabelas foram criadas.` });
    }
  };

  const prismaSchema = `// prisma/schema.prisma

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

generator client {
  provider = "prisma-client-js"
}

enum Priority {
  high
  medium
  low
}

enum QuoteStatus {
  new         // Nova Cotação / Triagem
  analysis    // Em Análise / Elaboração
  sent        // Enviada / Aguardando Resposta
  negotiation // Negociação / Ajustes
  won         // Ganha (Sucesso)
  lost        // Perdida / Cancelada
}

enum InsightCategory {
  improvement
  nicho
  supplier
  other
}

model User {
  id        String   @id @default(uuid())
  name      String
  avatar    String
  role      String   // "eu" | "ela"
  quotes    Quote[]  @relation("ResponsibleUser")
  createdAt DateTime @default(now())
}

model Quote {
  id            String         @id @default(uuid())
  clientName    String
  projectName   String
  contactPhone  String         // WhatsApp/Contato principal
  contactEmail  String
  description   String         @db.Text
  value         Decimal        @db.Decimal(12, 2)
  margin        Float          @default(0.0) // Margem de lucro estimada (%)
  estimatedDate DateTime?      // Prazo de Entrega
  status        QuoteStatus    @default(new)
  priority      Priority       @default(medium)
  
  // Relações
  responsibleId String
  responsible   User           @relation("ResponsibleUser", fields: [responsibleId], references: [id])
  feedbacks     FollowUp[]
  
  // Informações de Perda
  lossReason    String?        // "price" | "deadline" | "competitor" | "vanished" | "other"
  lossDetails   String?        @db.Text

  createdAt     DateTime       @default(now())
  updatedAt     DateTime       @updatedAt
}

model FollowUp {
  id        String   @id @default(uuid())
  quoteId   String
  quote     Quote    @relation(fields: [quoteId], references: [id], onDelete: Cascade)
  note      String   @db.Text
  createdBy String   // Nome de quem inseriu ("Eu" ou "Ela")
  createdAt DateTime @default(now())
}

model Insight {
  id          String          @id @default(uuid())
  title       String
  description String          @db.Text
  category    InsightCategory @default(other)
  createdBy   String          // Quem inseriu
  createdAt   DateTime        @default(now())
}`;

  const sqlSchema = `-- DDL SQL para executar no EDITOR SQL do Supabase
-- Copie e cole este código para criar as tabelas antes de sincronizar!

-- Criação dos tipos ENUM (se não existirem, ignore ou adicione tratamento)
CREATE TYPE "Priority" AS ENUM ('high', 'medium', 'low');
CREATE TYPE "QuoteStatus" AS ENUM ('new', 'analysis', 'sent', 'negotiation', 'won', 'lost');
CREATE TYPE "InsightCategory" AS ENUM ('improvement', 'nicho', 'supplier', 'other');

-- Tabela de Usuários (Eu e Esposa)
CREATE TABLE IF NOT EXISTS "User" (
  "id" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "avatar" TEXT NOT NULL,
  "role" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "User_pkey" PRIMARY KEY ("id")
);

-- Tabela de Cotações
CREATE TABLE IF NOT EXISTS "Quote" (
  "id" TEXT NOT NULL,
  "clientName" TEXT NOT NULL,
  "projectName" TEXT NOT NULL,
  "contactPhone" TEXT NOT NULL,
  "contactEmail" TEXT NOT NULL,
  "description" TEXT NOT NULL,
  "value" DECIMAL(12,2) NOT NULL,
  "margin" DOUBLE PRECISION NOT NULL DEFAULT 0.0,
  "estimatedDate" TIMESTAMP(3),
  "status" "QuoteStatus" NOT NULL DEFAULT 'new',
  "priority" "Priority" NOT NULL DEFAULT 'medium',
  "responsibleId" TEXT NOT NULL,
  "lossReason" TEXT,
  "lossDetails" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "Quote_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "Quote_responsibleId_fkey" FOREIGN KEY ("responsibleId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- Tabela de Logs de Acompanhamento (Antigo FeedbackLog - Renomeado para evitar falsos-positivos de AdBlockers)
CREATE TABLE IF NOT EXISTS "FollowUp" (
  "id" TEXT NOT NULL,
  "quoteId" TEXT NOT NULL,
  "note" TEXT NOT NULL,
  "createdBy" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "FollowUp_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "FollowUp_quoteId_fkey" FOREIGN KEY ("quoteId") REFERENCES "Quote"("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- Tabela de Inbox de Ideias e Insights
CREATE TABLE IF NOT EXISTS "Insight" (
  "id" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "description" TEXT NOT NULL,
  "category" "InsightCategory" NOT NULL DEFAULT 'other',
  "createdBy" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "Insight_pkey" PRIMARY KEY ("id")
);

-- Garantir acesso de leitura/escrita pública temporária para automação offline sem Auth Complexo:
ALTER TABLE "User" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Quote" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "FollowUp" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Insight" ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Acesso Livre User" ON "User" FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Acesso Livre Quote" ON "Quote" FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Acesso Livre FollowUp" ON "FollowUp" FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Acesso Livre Insight" ON "Insight" FOR ALL USING (true) WITH CHECK (true);`;

  const folderStructure = `meu-crm-casal/
├── prisma/
│   └── schema.prisma        # Definição do Banco PostgreSQL / SQLite
├── src/
│   ├── app/                 # Next.js App Router (Páginas e APIs)
│   │   ├── layout.tsx       # Layout Global (Fontes, Providers)
│   │   ├── page.tsx         # Página Principal (Redirecionamento/Login)
│   │   ├── dashboard/       # Painel de Controle (/dashboard)
│   │   │   └── page.tsx
│   │   ├── cotações/        # Funil Kanban (/cotações)
│   │   │   └── page.tsx
│   │   ├── insights/        # Módulo de Ideias (/insights)
│   │   │   └── page.tsx
│   │   └── api/             # Rotas de Back-end (REST API)
│   │       ├── quotes/
│   │       ├── feedbacks/
│   │       └── insights/
│   ├── components/          # Componentes Reutilizáveis de UI
│   │   ├── ui/              # Componentes base (Botão, Modal, Input)
│   │   ├── kanban-board.tsx # Funil de Vendas de Cotações completo
│   │   ├── timeline.tsx     # Histórico de Feedbacks da Cotação
│   │   ├── metric-card.tsx  # Indicadores com cor e flutuação
│   │   └── main-nav.tsx     # Navegação Responsiva com atalhos de celular
│   ├── lib/
│   │   └── db.ts            # Cliente Prisma Inicializado (Singleton)
│   └── types/
│       └── index.ts         # Tipos globais TypeScript`;

  const handleCopy = () => {
    const textToCopy = activeTab === 'prisma' ? prismaSchema : activeTab === 'sql' ? sqlSchema : folderStructure;
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div id="database-schema-section" className="bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-sm overflow-hidden text-left">
      {/* Header */}
      <div className="px-6 py-5 border-b border-zinc-200 dark:border-zinc-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-zinc-900 dark:text-white flex items-center gap-2">
            <Database className="w-5 h-5 text-amber-500 animate-[pulse_2s_infinite]" />
            Arquitetura & Engenharia de Dados M&N
          </h2>
          <p className="text-sm text-zinc-500 dark:text-zinc-400 mt-1">
            Visualizador de modelagem SQL, estruturas relacionais e ferramenta de integração na nuvem.
          </p>
        </div>

        {/* Tabs switcher */}
        <div className="flex bg-zinc-100 dark:bg-zinc-800/80 p-1 rounded-xl self-start sm:self-auto flex-wrap gap-1">
          <button
            id="tab-supabase"
            onClick={() => setActiveTab('supabase')}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'supabase'
                ? 'bg-amber-500 dark:bg-amber-600 text-white shadow-xs'
                : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
            }`}
          >
            <Cloud className="w-3.5 h-3.5 animate-[pulse_3s_infinite]" />
            Supabase Cloud
          </button>
          
          <button
            id="tab-sql"
            onClick={() => setActiveTab('sql')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'sql'
                ? 'bg-indigo-650 dark:bg-indigo-600 text-white shadow-xs'
                : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            Script SQL DDL
          </button>

          <button
            id="tab-prisma"
            onClick={() => setActiveTab('prisma')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'prisma'
                ? 'bg-zinc-800 dark:bg-zinc-700 text-white shadow-xs'
                : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" />
            Prisma Schema
          </button>

          <button
            id="tab-folders"
            onClick={() => setActiveTab('folders')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'folders'
                ? 'bg-zinc-800 dark:bg-zinc-700 text-white shadow-xs'
                : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
            }`}
          >
            <FolderTree className="w-3.5 h-3.5" />
            Pastas
          </button>
        </div>
      </div>

      {activeTab === 'supabase' ? (
        <div className="p-6 space-y-6">
          <div className="grid lg:grid-cols-12 gap-6">
            
            {/* Step instruction card */}
            <div className="lg:col-span-5 space-y-4">
              <div className="p-5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-sm">
                <span className="text-[10px] uppercase font-black tracking-wider bg-amber-600/20 text-amber-700 dark:text-amber-400 px-2 py-0.5 rounded-sm inline-block mb-2">
                  Pronto para a Nuvem
                </span>
                <h3 className="font-extrabold text-zinc-950 dark:text-amber-450 text-base mb-1.5 flex items-center gap-1.5">
                  <CloudLightning className="w-4 h-4 text-amber-500" /> Preparações para o Supabase
                </h3>
                <p className="text-xs text-zinc-600 dark:text-zinc-300 leading-relaxed">
                  Para hospedar o banco de dados do <strong>Energiza CRM</strong> no Supabase e gerenciar as cotações do casal online e sincronizados:
                </p>
                <ol className="list-decimal list-inside text-[11px] text-zinc-500 dark:text-zinc-400 space-y-1.5 mt-3 leading-normal">
                  <li>Crie uma conta gratuita em <a href="https://supabase.com" target="_blank" rel="noreferrer" className="text-amber-600 dark:text-amber-400 font-bold hover:underline">supabase.com</a>.</li>
                  <li>Inicie um projeto PostgreSQL e adicione as credenciais ao lado.</li>
                  <li>Copie e rode o script na aba <strong>Script SQL DDL</strong> no Editor SQL do painel do Supabase.</li>
                  <li>Clique em <strong>Testar Conexão</strong> e faça o envio ou resgate de dados em tempo real!</li>
                </ol>
              </div>

              {/* Status information panel */}
              <div className="bg-zinc-50 dark:bg-zinc-950 p-4 rounded-xl border border-zinc-200/60 dark:border-zinc-800/80 space-y-4">
                <div>
                  <h4 className="text-xs font-bold text-zinc-800 dark:text-zinc-300 mb-2 flex items-center gap-1.5">
                    <RefreshCw className="w-3.5 h-3.5 text-zinc-400" />
                    Status da Nuvem Energiza
                  </h4>
                  <div className="space-y-2 text-[11px]">
                    <div className="flex justify-between py-1 border-b border-zinc-150 dark:border-zinc-800/50">
                      <span className="text-zinc-400">Status de Conectividade:</span>
                      {isConnected ? (
                        <span className="font-extrabold text-emerald-500 flex items-center gap-1">🟢 Conectado</span>
                      ) : (
                        <span className="font-bold text-zinc-400 flex items-center gap-1">⚫ Offline Local (Seguro)</span>
                      )}
                    </div>
                    <div className="flex justify-between py-1 border-b border-zinc-150 dark:border-zinc-800/50">
                      <span className="text-zinc-400">Total Cotações locais:</span>
                      <span className="font-bold text-zinc-905 dark:text-zinc-200">{quotes.length} itens</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-zinc-150 dark:border-zinc-800/50">
                      <span className="text-zinc-400">Feedbacks de Acompanhamento:</span>
                      <span className="font-bold text-zinc-905 dark:text-zinc-200">{feedbacks.length} registros</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span className="text-zinc-400">Inbox de Ideias locais:</span>
                      <span className="font-bold text-zinc-905 dark:text-zinc-200">{insights.length} ideias</span>
                    </div>
                  </div>
                </div>

                {/* Sincronismo entre Dispositivos Guide */}
                <div className="border-t border-zinc-200 dark:border-zinc-800 pt-3 mt-1">
                  <h5 className="text-[11px] font-black text-amber-600 dark:text-amber-400 uppercase tracking-wider mb-2 flex items-center gap-1">
                    📱 Sincronização Celular + PC
                  </h5>
                  <p className="text-[10px] text-zinc-650 dark:text-zinc-400 leading-relaxed space-y-1">
                    Se você acessou o site no celular e as cotações antigas ainda aparecem lá, é porque <strong>o celular não tem as chaves do Supabase salvas nele</strong> (cada navegador tem seu próprio armazenamento local).
                  </p>
                  <div className="mt-2.5 space-y-2">
                    <div className="bg-amber-500/10 border border-amber-500/20 rounded-lg p-2.5 text-[10.5px] text-zinc-700 dark:text-zinc-300 leading-normal">
                      <span className="font-bold text-amber-600 dark:text-amber-400 block mb-0.5">🚀 Como resolver de vez (Recomendado):</span>
                      Configure as duas chaves como Variáveis de Ambiente no painel da <strong>Netlify</strong> (Settings &gt; Environment Variables) com os seguintes nomes exactos:
                      <ul className="list-disc list-inside font-mono text-[9px] mt-1 space-y-0.5 text-zinc-800 dark:text-zinc-200 bg-white/50 dark:bg-black/20 p-1.5 rounded-md">
                        <li>VITE_SUPABASE_URL</li>
                        <li>VITE_SUPABASE_ANON_KEY</li>
                      </ul>
                      <span className="block mt-1 text-[9.5px]">Após salvar e reimplantar (redeploy) na Netlify, todos os celulares, PCs e tablets conectarão ao banco de dados Supabase <strong>automaticamente, sem precisar configurar nada mais!</strong></span>
                    </div>

                    <div className="bg-zinc-100 dark:bg-zinc-905 border border-zinc-200 dark:border-zinc-800 rounded-lg p-2 text-[10px] text-zinc-600 dark:text-zinc-400 leading-normal">
                      <span className="font-bold text-zinc-750 dark:text-zinc-300 block mb-0.5">Ou resolva manualmente no celular agora:</span>
                      Basta acessar no seu celular esta aba <strong>Engenharia/DB</strong> e salvar a URL e Chave públicas do Supabase nos campos ao lado (iguais aos que você colocou no PC).
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Config & actions form */}
            <div className="lg:col-span-7 space-y-4">
              <div className="bg-zinc-50 dark:bg-zinc-950/70 p-5 rounded-2xl border border-zinc-205 dark:border-zinc-800/60 flex flex-col gap-4">
                <div className="border-b border-zinc-200 dark:border-zinc-800 pb-3">
                  <h3 className="text-xs font-black text-zinc-850 dark:text-zinc-350 uppercase tracking-widest flex items-center gap-1">
                    <KeyRound className="w-4 h-4 text-amber-500" />
                    Chaves de Conexão no Navegador
                  </h3>
                  <p className="text-[10px] text-zinc-400 mt-0.5">As credenciais ficam guardadas de forma segura apenas no seu navegador.</p>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="block text-[11px] font-bold text-zinc-600 dark:text-zinc-300 mb-1">SUPABASE_URL</label>
                    <input
                      type="text"
                      placeholder="Ex: https://xxxxxxxxx.supabase.co"
                      value={supabaseUrl}
                      onChange={(e) => setSupabaseUrl(e.target.value)}
                      className="w-full text-xs font-mono bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 px-3 py-2 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 text-zinc-800 dark:text-zinc-200"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-zinc-600 dark:text-zinc-300 mb-1">SUPABASE_ANON_KEY (Public Key)</label>
                    <input
                      type="password"
                      placeholder="Sua chave anônima (service_role ou anon_key)"
                      value={supabaseKey}
                      onChange={(e) => setSupabaseKey(e.target.value)}
                      className="w-full text-xs font-mono bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 px-3 py-2 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 text-zinc-800 dark:text-zinc-200"
                    />
                  </div>
                </div>

                {statusMsg.text && (
                  <div className={`p-3 rounded-xl text-xs flex items-start gap-1.5 leading-relaxed font-medium ${
                    statusMsg.type === 'success' 
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-250 dark:bg-emerald-950/20 dark:text-emerald-400 dark:border-emerald-900/50'
                      : statusMsg.type === 'error'
                      ? 'bg-rose-50 text-rose-800 border border-rose-200 dark:bg-rose-950/20 dark:text-rose-450 dark:border-rose-900/50'
                      : 'bg-indigo-50 text-indigo-800 border border-indigo-200 dark:bg-indigo-950/20 dark:text-indigo-400 dark:border-indigo-900/50'
                  }`}>
                    {statusMsg.type === 'success' && <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-500" />}
                    {statusMsg.type === 'error' && <AlertTriangle className="w-4 h-4 shrink-0 text-rose-500" />}
                    {statusMsg.type === 'loading' && <RefreshCw className="w-4 h-4 shrink-0 text-indigo-500 animate-spin" />}
                    <span>{statusMsg.text}</span>
                  </div>
                )}

                {/* Connection buttons bar */}
                <div className="flex gap-2.5">
                  <button
                    id="btn-save-credentials"
                    type="button"
                    onClick={handleSaveConfig}
                    className="flex-1 bg-zinc-850 dark:bg-zinc-850 hover:bg-zinc-800 select-none text-white font-bold p-2.5 rounded-xl text-xs transition-colors cursor-pointer"
                  >
                    Salvar Chaves
                  </button>
                  <button
                    id="btn-test-connection"
                    type="button"
                    onClick={handleTestConnection}
                    className="flex-1 bg-amber-500 hover:bg-amber-600 select-none text-white font-black p-2.5 rounded-xl text-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <Play className="w-3.5 h-3.5" />
                    Testar Conexão
                  </button>
                  {(supabaseUrl || supabaseKey) && (
                    <button
                      id="btn-clear-credentials"
                      type="button"
                      onClick={handleClearConfig}
                      className="text-xs font-bold text-zinc-400 hover:text-zinc-650 dark:hover:text-zinc-300 underline p-2 cursor-pointer transition-colors"
                    >
                      Limpar
                    </button>
                  )}
                </div>
              </div>

              {/* Data Synchronizer Tools Card */}
              <div className="bg-zinc-50 dark:bg-zinc-950/70 p-5 rounded-2xl border border-zinc-205 dark:border-zinc-800/60 space-y-4">
                <div className="border-b border-zinc-200 dark:border-zinc-800 pb-3">
                  <h3 className="text-xs font-black text-zinc-850 dark:text-zinc-350 uppercase tracking-widest">
                    🔄 Motor de Sincronização de Dados
                  </h3>
                  <p className="text-[10px] text-zinc-400 mt-0.5">Envie seu progresso local para o Supabase ou puxe a nuvem para esta máquina.</p>
                </div>

                <div className="grid sm:grid-cols-2 gap-3">
                  <button
                    id="btn-supabase-push"
                    type="button"
                    disabled={!isConnected}
                    onClick={handlePushSync}
                    className={`flex items-center justify-center gap-2 font-bold p-3 rounded-xl text-xs transition-all cursor-pointer ${
                      isConnected 
                        ? 'bg-amber-600 hover:bg-amber-750 text-white shadow-xs' 
                        : 'bg-zinc-200 dark:bg-zinc-900 text-zinc-400 cursor-not-allowed'
                    }`}
                  >
                    <ArrowUpRight className="w-4 h-4 text-white" />
                    Enviar Dados Locais p/ Nuvem
                  </button>

                  <button
                    id="btn-supabase-pull"
                    type="button"
                    disabled={!isConnected}
                    onClick={handlePullSync}
                    className={`flex items-center justify-center gap-2 font-bold p-3 rounded-xl text-xs transition-all cursor-pointer ${
                      isConnected 
                        ? 'bg-indigo-600 hover:bg-indigo-750 text-white shadow-xs' 
                        : 'bg-zinc-200 dark:bg-zinc-900 text-zinc-400 cursor-not-allowed'
                    }`}
                  >
                    <ArrowDownLeft className="w-4 h-4 text-white" />
                    Baixar Dados da Nuvem
                  </button>
                </div>

                {syncStatus.text && (
                  <div className={`p-3 rounded-xl text-xs font-semibold leading-relaxed ${
                    syncStatus.type === 'success'
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 dark:bg-emerald-950/20 dark:text-emerald-450 dark:border-emerald-900/50'
                      : syncStatus.type === 'error'
                      ? 'bg-rose-50 text-rose-800 border border-rose-200 dark:bg-rose-950/20 dark:text-rose-450 dark:border-rose-900/50'
                      : 'bg-amber-50 text-amber-800 border border-amber-200 dark:bg-amber-950/20 dark:text-amber-450 dark:border-amber-900/30 animate-pulse'
                  }`}>
                    <p className="flex items-center gap-1.5">
                      {syncStatus.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-500 inline-block shrink-0" />}
                      {syncStatus.type === 'error' && <ShieldAlert className="w-4 h-4 text-rose-500 inline-block shrink-0" />}
                      {syncStatus.type === 'syncing' && <RefreshCw className="w-4 h-4 text-amber-500 inline-block shrink-0 animate-spin" />}
                      <span>{syncStatus.text}</span>
                    </p>
                  </div>
                )}
              </div>

            </div>

          </div>
        </div>
      ) : (
        /* Regular architectural schemas view (Prisma, SQL, folders) */
        <div className="relative">
          {/* Copy Button */}
          <button
            id="btn-copy-schema"
            onClick={handleCopy}
            className="absolute top-4 right-4 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-600 dark:text-zinc-300 p-2 rounded-lg transition-colors border border-zinc-200 dark:border-zinc-700 cursor-pointer"
            title="Copiar código"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
          </button>

          <pre className="p-6 overflow-x-auto text-xs font-mono text-zinc-800 dark:text-zinc-300 bg-zinc-50 dark:bg-zinc-950 max-h-[460px] leading-relaxed">
            {activeTab === 'prisma' && prismaSchema}
            {activeTab === 'sql' && sqlSchema}
            {activeTab === 'folders' && folderStructure}
          </pre>
        </div>
      )}
    </div>
  );
}
