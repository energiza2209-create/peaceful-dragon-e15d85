/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  TrendingUp, TrendingDown, DollarSign, Briefcase, 
  AlertCircle, ShieldAlert, BadgePlus, CheckCircle,
  HelpCircle, Sparkles, Phone, MessageSquare,
  Smartphone, Apple, Chrome, X, ArrowUpRight
} from 'lucide-react';
import { 
  PieChart, Pie, Cell, ResponsiveContainer, 
  BarChart, Bar, XAxis, YAxis, Tooltip, Legend 
} from 'recharts';
import { Quote, FeedbackLog, User } from '../types';

interface DashboardProps {
  quotes: Quote[];
  feedbacks: FeedbackLog[];
  users: User[];
  onSelectQuote: (quote: Quote) => void;
}

export default function Dashboard({ quotes, feedbacks, users, onSelectQuote }: DashboardProps) {
  const [showInstallGuide, setShowInstallGuide] = useState(() => {
    return localStorage.getItem('energiza-hide-install-guide') !== 'true';
  });

  const handleDismissGuide = () => {
    localStorage.setItem('energiza-hide-install-guide', 'true');
    setShowInstallGuide(false);
  };
  
  // 1. Calculations for metrics
  const activeStatuses = ['new', 'analysis', 'sent', 'negotiation'];
  const activeQuotes = quotes.filter(q => activeStatuses.includes(q.status));
  const totalActiveValue = activeQuotes.reduce((acc, q) => acc + q.value, 0);

  const wonQuotes = quotes.filter(q => q.status === 'won');
  const wonValue = wonQuotes.reduce((acc, q) => acc + q.value, 0);

  const lostQuotes = quotes.filter(q => q.status === 'lost');
  const lostValue = lostQuotes.reduce((acc, q) => acc + q.value, 0);

  // Status breakdown calculations
  const statusCounts = {
    new: quotes.filter(q => q.status === 'new').length,
    analysis: quotes.filter(q => q.status === 'analysis').length,
    sent: quotes.filter(q => q.status === 'sent').length,
    negotiation: quotes.filter(q => q.status === 'negotiation').length,
    won: wonQuotes.length,
    lost: lostQuotes.length,
  };

  // Convert to chart data format
  const pieData = [
    { name: 'Triagem', value: statusCounts.new, color: '#6366f1' },       // Indigo
    { name: 'Elaborando', value: statusCounts.analysis, color: '#a855f7' },   // Purple
    { name: 'Enviada', value: statusCounts.sent, color: '#3b82f6' },       // Blue
    { name: 'Negociação', value: statusCounts.negotiation, color: '#f59e0b' },// Amber
    { name: 'Ganhos', value: statusCounts.won, color: '#10b981' },         // Emerald
    { name: 'Perdidas', value: statusCounts.lost, color: '#f43f5e' },       // Rose
  ].filter(item => item.value > 0); // Only display non-zero statuses

  // Bar chart: value by status
  const barData = [
    { name: 'Triagem', Valor: quotes.filter(q => q.status === 'new').reduce((acc, q) => acc + q.value, 0) },
    { name: 'Elaboraç.', Valor: quotes.filter(q => q.status === 'analysis').reduce((acc, q) => acc + q.value, 0) },
    { name: 'Enviada', Valor: quotes.filter(q => q.status === 'sent').reduce((acc, q) => acc + q.value, 0) },
    { name: 'Negoc.', Valor: quotes.filter(q => q.status === 'negotiation').reduce((acc, q) => acc + q.value, 0) },
    { name: 'Ganhos', Valor: wonValue },
    { name: 'Perdidos', Valor: lostValue },
  ];

  // Rate of success: won / (won + lost)
  const totalResolution = wonQuotes.length + lostQuotes.length;
  const winRate = totalResolution > 0 ? (wonQuotes.length / totalResolution) * 100 : 0;

  // 2. Action Alerts (no follow up for over 3 days = 72 hours)
  const alertsOfQuotes = activeQuotes.filter(q => {
    // find latest feedback
    const quoteFeedbacks = feedbacks.filter(f => f.quoteId === q.id);
    let lastActivityDate = new Date(q.createdAt);

    if (quoteFeedbacks.length > 0) {
      const sortedFb = [...quoteFeedbacks].sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
      lastActivityDate = new Date(sortedFb[0].createdAt);
    }

    const differenceInMs = new Date().getTime() - lastActivityDate.getTime();
    const differenceInDays = differenceInMs / (1000 * 60 * 60 * 24);

    return differenceInDays >= 3;
  }).map(q => {
    const qFeedbacks = feedbacks.filter(f => f.quoteId === q.id);
    let lastActivityDate = new Date(q.createdAt);
    let lastActivityText = 'Cote criada e aguarda andamento';

    if (qFeedbacks.length > 0) {
      const sortedFb = [...qFeedbacks].sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
      lastActivityDate = new Date(sortedFb[0].createdAt);
      lastActivityText = sortedFb[0].note.length > 50 ? sortedFb[0].note.substring(0, 50) + '...' : sortedFb[0].note;
    }

    const diffDays = Math.floor((new Date().getTime() - lastActivityDate.getTime()) / (1000 * 60 * 60 * 24));

    return {
      quote: q,
      daysWithoutFollowUp: diffDays,
      lastInteraction: lastActivityText,
    };
  }).sort((a, b) => b.daysWithoutFollowUp - a.daysWithoutFollowUp); // Most urgent alerts first

  return (
    <div id="dashboard-view" className="space-y-6">

      {/* Premium Mobile App PWA Installation Guide Banner */}
      {showInstallGuide && (
        <div id="pwa-install-banner" className="relative p-5 md:p-6 rounded-2xl bg-gradient-to-r from-amber-500/10 via-orange-500/5 to-transparent border border-amber-500/20 dark:border-amber-500/15 overflow-hidden text-left flex flex-col md:flex-row md:items-center justify-between gap-6 transition-all animate-slide-in">
          
          <button 
            onClick={handleDismissGuide}
            className="absolute top-4 right-4 text-zinc-400 hover:text-zinc-600 dark:hover:text-amber-400 transition-colors cursor-pointer p-1 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800"
            title="Ocultar guia de instalação"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="space-y-2 max-w-3xl">
            <div className="flex items-center gap-2">
              <span className="text-[9px] font-black uppercase tracking-widest bg-amber-500/20 text-text-amber-705 dark:text-amber-400 px-2 py-0.5 rounded-sm">
                100% Responsivo & Instalável
              </span>
              <span className="text-zinc-400 text-xs flex items-center gap-1">• Energiza CRM Cloud</span>
            </div>
            
            <h2 className="text-lg font-black text-zinc-900 dark:text-white flex items-center gap-2">
              <Smartphone className="w-5.5 h-5.5 text-amber-500 animate-[bounce_2s_infinite]" />
              Leve o CRM da Energiza no seu bolso! (Instalação no Celular)
            </h2>
            <p className="text-xs text-zinc-650 dark:text-zinc-400 leading-relaxed">
              Desenvolvemos este site usando tecnologia de <strong>Aplicativos Progressivos (PWA)</strong>. Isso significa que vocês podem "baixá-lo" diretamente do navegador nos aparelhos de vocês, funcionando como um aplicativo real de celular (sem ocupar espaço de fotos e com carregamento instantâneo!).
            </p>

            {/* Quick columns */}
            <div className="grid sm:grid-cols-2 gap-4 pt-3 text-xs">
              {/* Android Matheus */}
              <div className="p-3.5 rounded-xl bg-white/50 dark:bg-zinc-900/60 border border-zinc-150 dark:border-zinc-850">
                <div className="flex items-center gap-1.5 font-bold text-zinc-800 dark:text-zinc-200 mb-2">
                  <Chrome className="w-4 h-4 text-emerald-500 shrink-0" />
                  No seu Android (Matheus):
                </div>
                <ul className="space-y-1.5 text-[11px] text-zinc-500 dark:text-zinc-400 list-decimal list-inside leading-snug">
                  <li>Abra o site no navegador <strong className="text-zinc-700 dark:text-zinc-300">Google Chrome</strong> do seu celular.</li>
                  <li>Toque no menu de <strong className="text-zinc-700 dark:text-zinc-300">3 pontinhos</strong> localizado no topo direito.</li>
                  <li>Toque na opção <span className="font-extrabold text-amber-600 dark:text-amber-400">"Instalar aplicativo"</span> ou <span className="font-semibold text-zinc-700 dark:text-zinc-300">"Adicionar à tela inicial"</span>.</li>
                  <li>Pronto! Ele aparecerá na sua tela de início com o ícone oficial.</li>
                </ul>
              </div>

              {/* iPhone Nara Rubia */}
              <div className="p-3.5 rounded-xl bg-white/50 dark:bg-zinc-900/60 border border-zinc-150 dark:border-zinc-850">
                <div className="flex items-center gap-1.5 font-bold text-zinc-800 dark:text-zinc-200 mb-2">
                  <Apple className="w-4 h-4 text-amber-500 shrink-0" />
                  No iPhone de Nara (Safari):
                </div>
                <ul className="space-y-1.5 text-[11px] text-zinc-500 dark:text-zinc-400 list-decimal list-inside leading-snug">
                  <li>Abra o link obrigatoriamente pelo navegador <strong className="text-zinc-700 dark:text-zinc-300">Safari</strong> do iPhone.</li>
                  <li>Toque no botão de <strong className="text-zinc-700 dark:text-zinc-300">Compartilhar</strong> (ícone quadrado com uma seta para cima).</li>
                  <li>Role a tela para baixo e clique em <span className="font-extrabold text-amber-600 dark:text-amber-400">"Adicionar à Tela de Início"</span>.</li>
                  <li>Confirme clicando em Adicionar no canto superior direito do iPhone!</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="shrink-0 flex self-start md:self-auto pt-2 md:pt-0">
            <span className="text-[10px] text-zinc-400 dark:text-zinc-500 font-extrabold flex items-center gap-1.5 uppercase tracking-wider">
              ⚡ Sincronia de Alta Velocidade
            </span>
          </div>

        </div>
      )}
      
      {/* Quick Metrics Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Metric 1: Active Quotes */}
        <div id="metric-active" className="bg-white dark:bg-zinc-900 p-5 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest">Ativas no Funil</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-3xl font-extrabold text-zinc-900 dark:text-white">{activeQuotes.length}</span>
              <span className="text-xs text-indigo-500 font-semibold bg-indigo-50 dark:bg-indigo-950/40 px-1.5 py-0.5 rounded-sm">Roda</span>
            </div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 flex items-center justify-center text-indigo-600 dark:text-indigo-400">
            <Briefcase className="w-6 h-6" />
          </div>
        </div>

        {/* Metric 2: Value in Negotiation */}
        <div id="metric-values" className="bg-white dark:bg-zinc-900 p-5 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest">Valor em Negociação</span>
            <div className="mt-1">
              <span className="text-2xl font-extrabold text-zinc-900 dark:text-white">
                {totalActiveValue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 })}
              </span>
            </div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
            <DollarSign className="w-6 h-6" />
          </div>
        </div>

        {/* Metric 3: Won Quotes */}
        <div id="metric-won" className="bg-white dark:bg-zinc-900 p-5 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest">Cotações Ganhas (Total)</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-3xl font-extrabold text-emerald-600 dark:text-emerald-400">{wonQuotes.length}</span>
              <span className="text-xs text-zinc-500 dark:text-zinc-400">
                ({wonValue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 })})
              </span>
            </div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-100 dark:bg-emerald-950/30 flex items-center justify-center text-emerald-600">
            <CheckCircle className="w-6 h-6" />
          </div>
        </div>

        {/* Metric 4: Success Rate Percentage */}
        <div id="metric-lost" className="bg-white dark:bg-zinc-900 p-5 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest">Taxa de Conversão</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-3xl font-extrabold text-indigo-600 dark:text-indigo-400">{winRate.toFixed(1)}%</span>
              <span className="text-xs text-zinc-400">({wonQuotes.length}/{totalResolution} decididos)</span>
            </div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-indigo-100 dark:bg-indigo-950/30 flex items-center justify-center text-indigo-600">
            <TrendingUp className="w-6 h-6" />
          </div>
        </div>

      </div>

      {/* Main Content Splitted Area (Charts + Alerts) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Side: Conversion and Volume Charts (Span 8) */}
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-white dark:bg-zinc-900 p-6 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-base font-bold text-zinc-900 dark:text-white">Relatório Visual do Funil de Vendas</h3>
                <p className="text-xs text-zinc-400 mt-0.5">Distribuição do volume monetário e frequência das cotações em andamento.</p>
              </div>
            </div>

            {/* Split charts layout */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 min-h-[280px]">
              
              {/* Frequency Pie Chart (Span 5) */}
              <div className="md:col-span-5 flex flex-col justify-between border-b md:border-b-0 md:border-r border-zinc-100 dark:border-zinc-800 pb-6 md:pb-0 md:pr-6">
                <span className="text-xs font-bold text-zinc-500 dark:text-zinc-400 block mb-2 text-center md:text-left">Cotações por Status (Qtd)</span>
                
                {pieData.length === 0 ? (
                  <div className="flex-1 flex items-center justify-center text-center text-xs text-zinc-400 py-10">
                    Insira dados de cotação para projetar o funil de pizza.
                  </div>
                ) : (
                  <>
                    <div className="h-[180px] w-full self-center">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={pieData}
                            cx="50%"
                            cy="50%"
                            innerRadius={50}
                            outerRadius={75}
                            paddingAngle={3}
                            dataKey="value"
                          >
                            {pieData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Pie>
                          <Tooltip 
                            contentStyle={{ 
                              background: '#18181b', 
                              border: 'none', 
                              borderRadius: '8px',
                              fontSize: '11px',
                              color: '#fff'
                            }} 
                          />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>

                    {/* Legends mini list */}
                    <div className="grid grid-cols-3 gap-1.5 pt-2">
                      {pieData.map((item, idx) => (
                        <div key={idx} className="flex items-center gap-1.5 text-[10px]">
                          <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: item.color }} />
                          <span className="text-zinc-600 dark:text-zinc-300 truncate font-medium">
                            {item.name}: <strong>{item.value}</strong>
                          </span>
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </div>

              {/* Worth Bar Chart (Span 7) */}
              <div className="md:col-span-7 flex flex-col justify-between">
                <span className="text-xs font-bold text-zinc-500 dark:text-zinc-400 block mb-2">VolumeFinanceiro por Estágio (R$)</span>
                
                <div className="h-[200px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={barData}
                      margin={{ top: 5, right: 5, left: -20, bottom: 5 }}
                    >
                      <XAxis dataKey="name" stroke="#888888" fontSize={9} tickLine={false} axisLine={false} />
                      <YAxis stroke="#888888" fontSize={9} tickLine={false} axisLine={false} />
                      <Tooltip
                        cursor={{ fill: 'rgba(255,255,255,0.05)' }}
                        formatter={(val) => [`R$ ${Number(val).toLocaleString('pt-BR')}`, 'Volume Total']}
                        contentStyle={{ 
                          background: '#18181b', 
                          border: 'none', 
                          borderRadius: '8px',
                          fontSize: '11px',
                          color: '#fff'
                        }} 
                      />
                      <Bar dataKey="Valor" fill="#4f46e5" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>

                <div className="text-[10px] text-zinc-500 text-right italic">
                  Volume Geral Negociando: R$ {totalActiveValue.toLocaleString('pt-BR')}
                </div>
              </div>

            </div>

          </div>
        </div>

        {/* Right Side: Follow-up Alerts System (Span 4) */}
        <div className="lg:col-span-4 flex flex-col">
          <div className="bg-white dark:bg-zinc-900 p-6 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs flex-1 flex flex-col">
            <div className="flex items-center gap-2 mb-4 border-b border-zinc-150 dark:border-zinc-800/80 pb-3">
              <AlertCircle className="w-5 h-5 text-amber-500 animate-pulse shrink-0" />
              <div>
                <h3 className="text-sm font-bold text-zinc-900 dark:text-white">Alertas de Ação (Follow-up)</h3>
                <p className="text-[10px] text-zinc-400 mt-0.5">Sem follow-up há 3 dias ou mais.</p>
              </div>
            </div>

            {/* Scrollable list constraint */}
            <div className="flex-1 overflow-y-auto space-y-3 pr-1 max-h-[350px]">
              {alertsOfQuotes.length === 0 ? (
                <div className="text-center py-10 flex flex-col items-center justify-center gap-2">
                  <div className="w-12 h-12 rounded-full bg-emerald-50 dark:bg-emerald-950/20 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
                    <Sparkles className="w-6 h-6" />
                  </div>
                  <span className="text-xs font-semibold text-emerald-700 dark:text-emerald-400">Tudo em dia!</span>
                  <p className="text-[10px] text-zinc-400 max-w-[200px]">Parabéns! Todas as cotações ativas receberam interação nos últimos 3 dias.</p>
                </div>
              ) : (
                alertsOfQuotes.map(({ quote, daysWithoutFollowUp, lastInteraction }, index) => {
                  const responsibleName = users.find(u => u.id === quote.responsibleId)?.name || 'N/A';
                  return (
                    <div 
                      key={quote.id}
                      onClick={() => onSelectQuote(quote)}
                      id={`alert-quote-card-${quote.id}`}
                      className="group p-3 rounded-xl border border-amber-250 dark:border-amber-900/20 bg-amber-50/45 hover:bg-amber-100/30 dark:bg-amber-950/10 dark:hover:bg-amber-950/20 transition-all cursor-pointer text-left border-l-4 border-l-amber-500"
                    >
                      <div className="flex justify-between items-start gap-1.5 mb-1.5">
                        <span className="text-xs font-bold text-zinc-800 dark:text-zinc-200 line-clamp-1">
                          {quote.clientName} ({quote.projectName})
                        </span>
                        <span className="text-[9px] font-extrabold text-amber-800 dark:text-amber-400 bg-amber-200/50 dark:bg-amber-900/40 px-2 py-0.5 rounded-sm shrink-0">
                          {daysWithoutFollowUp} DIAS ATRASADO
                        </span>
                      </div>

                      <p className="text-[11px] text-zinc-500 dark:text-zinc-400 italic line-clamp-2 leading-relaxed">
                        Último: "{lastInteraction}"
                      </p>

                      <div className="flex justify-between items-center mt-2.5 pt-2 border-t border-amber-250/20 dark:border-amber-900/15 text-[10px]">
                        <span className="text-zinc-405">Responsável: <strong className="text-zinc-650 dark:text-zinc-350">{responsibleName}</strong></span>
                        <span className="text-indigo-600 dark:text-indigo-400 font-semibold group-hover:underline flex items-center gap-0.5">
                          Resolver
                          <TrendingUp className="w-3 h-3 rotate-90" />
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* General tips banner */}
            <div className="mt-4 p-3 rounded-xl bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-100 dark:border-indigo-900/40 text-[11px] text-indigo-700 dark:text-indigo-400 flex items-start gap-2">
              <Sparkles className="w-4 h-4 text-indigo-500 shrink-0 mt-0.5" />
              <p className="leading-tight">
                Mantenha as conversas aquecidas! Um follow-up oportuno aumenta as taxas globais de fechamento em até 35%.
              </p>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
}
