/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Plus, Calendar, Phone, DollarSign, User, 
  ArrowLeft, ArrowRight, Kanban, Search, Filter, 
  Sparkles, CheckCircle2, AlertTriangle, AlertCircle, MessageSquare
} from 'lucide-react';
import { Quote, QuoteStatus, Priority, User as CRMUser, KanbanColumn } from '../types';

interface KanbanBoardProps {
  quotes: Quote[];
  feedbacks: any[]; // Feedback logs reference to count items
  users: CRMUser[];
  onUpdateQuote: (quote: Quote) => void;
  onAddQuote: (newQuote: Omit<Quote, 'id' | 'createdAt' | 'updatedAt'>) => void;
  onSelectQuote: (quote: Quote) => void;
  activeUserId: string;
  prefillNewQuoteProject?: string; // Support seamless conversions from insights!
  prefillNewQuoteDesc?: string;
  onClearPrefills?: () => void;
}

const COLUMNS: KanbanColumn[] = [
  { id: 'new', title: '1. Nova / Triagem', color: 'border-t-indigo-500 hover:bg-zinc-50/50 dark:hover:bg-zinc-950/20' },
  { id: 'analysis', title: '2. Em Elaboração', color: 'border-t-purple-500 hover:bg-zinc-50/50 dark:hover:bg-zinc-950/20' },
  { id: 'sent', title: '3. Enviada ao Cliente', color: 'border-t-blue-500 hover:bg-zinc-50/50 dark:hover:bg-zinc-950/20' },
  { id: 'negotiation', title: '4. Negociação / Ajustes', color: 'border-t-amber-500 hover:bg-zinc-50/50 dark:hover:bg-zinc-950/20' },
  { id: 'won', title: '5. Ganha (Sucesso) 🎉', color: 'border-t-emerald-500 hover:bg-emerald-50/10 dark:hover:bg-emerald-950/10' },
  { id: 'lost', title: '6. Perdida / Cancelada ❌', color: 'border-t-rose-500 hover:bg-rose-50/10 dark:hover:bg-rose-950/10' },
];

export default function KanbanBoard({
  quotes,
  feedbacks,
  users,
  onUpdateQuote,
  onAddQuote,
  onSelectQuote,
  activeUserId,
  prefillNewQuoteProject,
  prefillNewQuoteDesc,
  onClearPrefills,
}: KanbanBoardProps) {
  
  // Searches & Filter configurations
  const [searchQuery, setSearchQuery] = useState('');
  const [filterPriority, setFilterPriority] = useState<Priority | 'all'>('all');
  const [filterResponsible, setFilterResponsible] = useState<string | 'all'>('all');

  // Horizontal scroll & drag-to-scroll controllers for the Kanban board columns
  const scrollRef = React.useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const [scrollStartLeft, setScrollStartLeft] = useState(0);

  const handleMouseDown = (e: React.MouseEvent) => {
    const target = e.target as HTMLElement;
    // Do not initiate drag scrolling if we click buttons, cards, selects, textareas or inputs
    if (
      target.closest('button') || 
      target.closest('select') || 
      target.closest('input') || 
      target.closest('textarea') || 
      target.closest('[id^="kanban-card-"]')
    ) {
      return;
    }
    setIsDragging(true);
    setStartX(e.pageX - (scrollRef.current?.offsetLeft || 0));
    setScrollStartLeft(scrollRef.current?.scrollLeft || 0);
  };

  const handleMouseLeave = () => {
    setIsDragging(false);
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || !scrollRef.current) return;
    e.preventDefault();
    const x = e.pageX - (scrollRef.current.offsetLeft || 0);
    const walk = (x - startX) * 1.6; // Scroll sensitivity multiplier
    scrollRef.current.scrollLeft = scrollStartLeft - walk;
  };

  // Quick Inline Creation Form states
  const [isCreatingInColumn, setIsCreatingInColumn] = useState<QuoteStatus | null>(null);
  
  // New Quote form states
  const [clientName, setClientName] = useState('');
  const [projectName, setProjectName] = useState(prefillNewQuoteProject || '');
  const [contactPhone, setContactPhone] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [description, setDescription] = useState(prefillNewQuoteDesc || '');
  const [value, setValue] = useState<number>(0);
  const [margin, setMargin] = useState<number>(30); // 30% margin default
  const [estimatedDate, setEstimatedDate] = useState('');
  const [priority, setPriority] = useState<Priority>('medium');
  const [responsibleId, setResponsibleId] = useState(activeUserId);

  // If a pre-filled value comes from "Insights", trigger creation form in col "new" automatically!
  React.useEffect(() => {
    if (prefillNewQuoteProject) {
      setProjectName(prefillNewQuoteProject);
      setDescription(prefillNewQuoteDesc || '');
      setResponsibleId(activeUserId);
      setIsCreatingInColumn('new');
    }
  }, [prefillNewQuoteProject, prefillNewQuoteDesc]);

  // Cancel form
  const handleCancelCreate = () => {
    setIsCreatingInColumn(null);
    setClientName('');
    setProjectName('');
    setContactPhone('');
    setContactEmail('');
    setDescription('');
    setValue(0);
    setMargin(30);
    setEstimatedDate('');
    setPriority('medium');
    setResponsibleId(activeUserId);
    
    if (onClearPrefills) onClearPrefills();
  };

  const handleCreateSubmit = (e: React.FormEvent, targetStatus: QuoteStatus) => {
    e.preventDefault();
    if (!clientName.trim() || !projectName.trim()) return;

    onAddQuote({
      clientName: clientName.trim(),
      projectName: projectName.trim(),
      contactPhone: contactPhone.trim(),
      contactEmail: contactEmail.trim(),
      description: description.trim(),
      value: Number(value) || 0,
      margin: Number(margin) || 0,
      estimatedDate: estimatedDate || new Date(Date.now() + 7 * 24 * 3600 * 1000).toISOString().split('T')[0], // 7 days default
      status: targetStatus,
      priority,
      responsibleId,
    });

    handleCancelCreate();
  };

  // Drag and Drop implementation
  const handleDragStart = (e: React.DragEvent, quoteId: string) => {
    e.dataTransfer.setData('text/plain', quoteId);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent, targetStatus: QuoteStatus) => {
    e.preventDefault();
    const id = e.dataTransfer.getData('text/plain');
    if (!id) return;

    const quote = quotes.find(q => q.id === id);
    if (!quote || quote.status === targetStatus) return;

    // Moving quotes status
    const updated = { ...quote, status: targetStatus, updatedAt: new Date().toISOString() };
    onUpdateQuote(updated);
  };

  // Manual Quick-Move controllers (highly accessible & perfect for mobile)
  const handleQuickMove = (quote: Quote, direction: 'left' | 'right') => {
    const currentIndex = COLUMNS.findIndex(c => c.id === quote.status);
    let targetIndex = currentIndex;

    if (direction === 'left' && currentIndex > 0) {
      targetIndex = currentIndex - 1;
    } else if (direction === 'right' && currentIndex < COLUMNS.length - 1) {
      targetIndex = currentIndex + 1;
    }

    if (targetIndex !== currentIndex) {
      const updated = {
        ...quote,
        status: COLUMNS[targetIndex].id,
        updatedAt: new Date().toISOString(),
      };
      onUpdateQuote(updated);
    }
  };

  // Filter quotes based on queries
  const filteredQuotes = quotes.filter(q => {
    const matchesSearch = 
      q.clientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      q.projectName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      q.description.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesPriority = filterPriority === 'all' || q.priority === filterPriority;
    const matchesResponsible = filterResponsible === 'all' || q.responsibleId === filterResponsible;

    return matchesSearch && matchesPriority && matchesResponsible;
  });

  // Priority layout translations
  const getPriorityBadgeAndLabel = (prio: Priority) => {
    switch (prio) {
      case 'high':
        return {
          bg: 'bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-450',
          dotBg: 'bg-rose-500',
          label: 'Prioridade Alta',
        };
      case 'medium':
        return {
          bg: 'bg-amber-55 dark:bg-amber-950/40 text-amber-700 dark:text-amber-450',
          dotBg: 'bg-amber-500',
          label: 'Prioridade Média',
        };
      case 'low':
        return {
          bg: 'bg-zinc-100 dark:bg-zinc-800 text-zinc-650 dark:text-zinc-400',
          dotBg: 'bg-zinc-400',
          label: 'Prioridade Baixa',
        };
    }
  };

  return (
    <div id="kanban-area" className="space-y-6">
      
      {/* Search & filters panel */}
      <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 p-4 rounded-2xl shadow-xs flex flex-col md:flex-row gap-4 items-center justify-between text-left">
        
        {/* Left Side: Search Bar */}
        <div className="relative w-full md:max-w-md">
          <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-zinc-400 dark:text-zinc-505">
            <Search className="w-4 h-4" />
          </span>
          <input
            id="kanban-search"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar por cliente ou projeto..."
            className="w-full bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-750 pl-9 pr-4 py-2 rounded-xl text-sm text-zinc-805 dark:text-zinc-100 placeholder-zinc-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
          />
        </div>

        {/* Right Side: Simple Dropdowns */}
        <div className="w-full md:w-auto flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          
          {/* Priority filter */}
          <div className="flex items-center gap-2">
            <Filter className="w-3.5 h-3.5 text-zinc-450" />
            <select
              id="filter-priority"
              value={filterPriority}
              onChange={(e) => setFilterPriority(e.target.value as any)}
              className="bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-750 text-xs rounded-lg p-2 font-medium text-zinc-700 dark:text-zinc-350 focus:outline-hidden"
            >
              <option value="all">Prioridade: Todas</option>
              <option value="high">Alta 🔥</option>
              <option value="medium">Média ⏳</option>
              <option value="low">Baixa 💡</option>
            </select>
          </div>

          {/* Responsible filter */}
          <div className="flex items-center gap-2">
            <User className="w-3.5 h-3.5 text-zinc-450" />
            <select
              id="filter-responsible"
              value={filterResponsible}
              onChange={(e) => setFilterResponsible(e.target.value)}
              className="bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-750 text-xs rounded-lg p-2 font-medium text-zinc-700 dark:text-zinc-350 focus:outline-hidden"
            >
              <option value="all">Responsável: Ambos</option>
              {users.map(u => (
                <option key={u.id} value={u.id}>{u.name}</option>
              ))}
            </select>
          </div>

          {/* New quote button in header */}
          <button
            id="btn-trigger-new-quote"
            onClick={() => setIsCreatingInColumn('new')}
            className="bg-indigo-600 hover:bg-indigo-550 active:bg-indigo-700 text-white text-xs font-semibold px-4.5 py-2 rounded-xl flex items-center justify-center gap-1.5 shadow-sm transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Nova Cotação
          </button>
        </div>

      </div>

      {/* Kanban Board Row (Scrollable wrapper horizontal table) */}
      <div 
        ref={scrollRef}
        onMouseDown={handleMouseDown}
        onMouseLeave={handleMouseLeave}
        onMouseUp={handleMouseUp}
        onMouseMove={handleMouseMove}
        className="overflow-x-scroll pb-4 rounded-2xl border border-zinc-200/60 dark:border-zinc-850/60 bg-zinc-100/50 dark:bg-zinc-950/20 p-2.5 custom-horizontal-scroll grab-scroll-container transition-all touch-pan-x select-none scroll-smooth"
      >
        <div className="flex gap-4 min-w-[1740px] px-0.5">
          {COLUMNS.map((col) => {
            const columnQuotes = filteredQuotes.filter(q => q.status === col.id);
            const totalValue = columnQuotes.reduce((prev, curr) => prev + curr.value, 0);

            return (
              <div
                key={col.id}
                id={`kanban-column-${col.id}`}
                onDragOver={handleDragOver}
                onDrop={(e) => handleDrop(e, col.id)}
                className={`flex-none min-h-[440px] w-[275px] bg-zinc-50/70 dark:bg-zinc-900/40 border-t-4 border border-zinc-200/80 dark:border-zinc-800/80 rounded-xl flex flex-col p-3 transition-colors ${col.color}`}
              >
                
                {/* Column Title with Meta */}
                <div className="flex items-center justify-between gap-1.5 mb-2.5">
                  <h4 className="text-xs font-bold text-zinc-800 dark:text-zinc-200 uppercase tracking-wider truncate">
                    {col.title}
                  </h4>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-zinc-200/80 dark:bg-zinc-800 text-zinc-650 dark:text-zinc-300 shrink-0">
                    {columnQuotes.length}
                  </span>
                </div>

                {/* Column Currency Total */}
                <div className="text-[11px] font-medium text-zinc-500 dark:text-zinc-450 border-b border-zinc-200/60 dark:border-zinc-800/80 pb-2 mb-3 flex items-center justify-between">
                  <span>Total Bruto:</span>
                  <span className="font-extrabold text-zinc-700 dark:text-zinc-300">
                    {totalValue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 })}
                  </span>
                </div>

                {/* Inline Addition trigger */}
                <button
                  id={`btn-inline-add-${col.id}`}
                  onClick={() => setIsCreatingInColumn(col.id)}
                  className="w-full border border-dashed border-zinc-200 dark:border-zinc-800 rounded-lg py-1.5 text-xs text-zinc-450 dark:text-zinc-500 hover:text-indigo-600 dark:hover:text-indigo-400 hover:border-indigo-400/50 flex items-center justify-center gap-1 transition-all cursor-pointer mb-3 bg-white dark:bg-zinc-900/10"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Adicionar Cotação
                </button>

                {/* Card stream in column */}
                <div className="flex-1 space-y-3 overflow-y-auto max-h-[50vh] scrollbar-none">
                  {columnQuotes.length === 0 ? (
                    <div className="text-center py-8 text-[11px] text-zinc-400 italic">
                      Livre
                    </div>
                  ) : (
                    columnQuotes.map((q) => {
                      const prioTheme = getPriorityBadgeAndLabel(q.priority);
                      const responsibleUser = users.find(u => u.id === q.responsibleId);
                      
                      // Count feedbacks logs
                      const fbCount = feedbacks.filter(f => f.quoteId === q.id).length;

                      return (
                        <div
                          key={q.id}
                          id={`kanban-card-${q.id}`}
                          draggable
                          onDragStart={(e) => handleDragStart(e, q.id)}
                          onClick={() => onSelectQuote(q)}
                          className="bg-white dark:bg-zinc-950 rounded-xl border border-zinc-200 dark:border-zinc-800 shadow-xs hover:shadow-xs transition-shadow duration-150 p-4 relative group cursor-pointer text-left border-l-3 border-l-zinc-300 dark:border-l-zinc-700"
                        >
                          <div className="space-y-2.5">
                            {/* Card top flags */}
                            <div className="flex items-center justify-between gap-1.5">
                              <span className={`px-2 py-0.5 rounded-sm text-[9px] font-bold uppercase tracking-wide inline-flex items-center gap-1 ${prioTheme.bg}`}>
                                <span className={`w-1.5 h-1.5 rounded-full ${prioTheme.dotBg}`} />
                                {prioTheme.label}
                              </span>

                              <div className="flex items-center gap-1 text-[10px] text-zinc-400 shrink-0">
                                <span className="font-mono">#{q.id.substring(0, 4)}</span>
                              </div>
                            </div>

                            {/* Client & project naming */}
                            <div>
                              <h5 className="text-[11px] text-zinc-400 dark:text-zinc-500 font-bold uppercase tracking-wider line-clamp-1 leading-none">{q.clientName}</h5>
                              <h4 className="text-sm font-extrabold text-zinc-900 dark:text-white line-clamp-2 mt-0.5 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                                {q.projectName}
                              </h4>
                            </div>

                            {/* Spec excerpt */}
                            {q.description && (
                              <p className="text-[11px] text-zinc-500 dark:text-zinc-400 line-clamp-2 leading-relaxed">
                                {q.description}
                              </p>
                            )}

                            {/* Pricing & Margins metrics */}
                            <div className="flex items-center justify-between gap-1.5 bg-zinc-50 dark:bg-zinc-900/60 p-2 rounded-lg text-xs border border-zinc-100 dark:border-zinc-800/80">
                              <div className="flex flex-col">
                                <span className="text-[9px] text-zinc-400 font-medium">Preço</span>
                                <span className="font-extrabold text-zinc-800 dark:text-zinc-200">
                                  {q.value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 })}
                                </span>
                              </div>
                              <div className="flex flex-col text-right">
                                <span className="text-[9px] text-zinc-400 font-medium">Margem ({q.margin}%)</span>
                                <span className="font-bold text-emerald-650 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/20 px-1 py-0.5 rounded-sm">
                                  {((q.value * q.margin) / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 })}
                                </span>
                              </div>
                            </div>

                            {/* Card Footer: Date, responsible & feedback counters */}
                            <div className="flex items-center justify-between gap-1.5 pt-2 border-t border-zinc-150 dark:border-zinc-900/80">
                              <span className="text-[10px] text-zinc-400 dark:text-zinc-500 flex items-center gap-1 font-medium whitespace-nowrap">
                                <Calendar className="w-3 h-3" />
                                {q.estimatedDate ? new Date(q.estimatedDate + 'T00:00:00').toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' }) : 'S/ data'}
                              </span>

                              {/* Feedbacks counter log */}
                              <div className="flex items-center gap-2.5">
                                {fbCount > 0 && (
                                  <span className="text-[10px] text-indigo-650 dark:text-indigo-400 font-bold bg-indigo-50 dark:bg-indigo-950/40 px-1.5 py-0.5 rounded-md flex items-center gap-0.5" title={`${fbCount} interações registradas`}>
                                    <MessageSquare className="w-3 h-3" />
                                    {fbCount}
                                  </span>
                                )}

                                {/* Responsible executor bubble badge */}
                                <div className="flex items-center gap-1" title={`Atribuído a: ${responsibleUser?.name || 'Desconhecido'}`}>
                                  {responsibleUser?.avatar ? (
                                    <span className="text-xs">{responsibleUser.avatar}</span>
                                  ) : (
                                    <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold uppercase select-none ${
                                      responsibleUser?.role === 'eu' 
                                        ? 'bg-indigo-600 text-white' 
                                        : 'bg-rose-500 text-white'
                                    }`}>
                                      {responsibleUser ? responsibleUser.name.substring(0, 2) : '??'}
                                    </span>
                                  )}
                                  <span className="text-[10px] font-semibold text-zinc-650 dark:text-zinc-400 hidden group-hover:inline">
                                    {responsibleUser?.name.split(' ')[0]}
                                  </span>
                                </div>
                              </div>
                            </div>

                            {/* Mobile Quick Arrow Navigation Controllers (perfect mobile experience) */}
                            <div className="hidden max-md:flex items-center justify-between border-t border-zinc-100 dark:border-zinc-900/80 pt-2 text-zinc-400">
                              <button
                                id={`btn-move-left-${q.id}`}
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleQuickMove(q, 'left');
                                }}
                                className="p-1 px-3 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-md hover:text-zinc-700"
                                title="Mover para a esquerda"
                              >
                                <ArrowLeft className="w-3.5 h-3.5" />
                              </button>
                              <span className="text-[9px] uppercase tracking-widest text-[#71717a]">Andamento</span>
                              <button
                                id={`btn-move-right-${q.id}`}
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleQuickMove(q, 'right');
                                }}
                                className="p-1 px-3 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-md hover:text-zinc-700"
                                title="Mover para a direita"
                              >
                                <ArrowRight className="w-3.5 h-3.5" />
                              </button>
                            </div>

                          </div>
                        </div>
                      );
                    })
                  )}
                </div>

              </div>
            );
          })}
        </div>
      </div>

      {/* Pop-up Modal de Nova Cotação */}
      {isCreatingInColumn !== null && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl max-w-xl w-full shadow-2xl overflow-hidden flex flex-col text-left max-h-[90vh] duration-200 animate-in fade-in-50 zoom-in-95">
            
            {/* Modal Header */}
            <div className="px-6 py-4 border-b border-zinc-200 dark:border-zinc-800 flex justify-between items-center bg-zinc-50 dark:bg-zinc-950">
              <div className="flex items-center gap-2">
                <span className="p-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400">
                  <Sparkles className="w-5 h-5" />
                </span>
                <div>
                  <h3 className="text-base font-bold text-zinc-900 dark:text-white">Cadastrar Nova Cotação</h3>
                  <p className="text-xs text-zinc-400 dark:text-zinc-500">Insira as informações do cliente e o escopo do serviço.</p>
                </div>
              </div>
              <button
                id="btn-modal-close"
                type="button"
                onClick={handleCancelCreate}
                className="text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 transition-colors cursor-pointer"
              >
                <Plus className="w-5 h-5 rotate-45" />
              </button>
            </div>

            {/* Modal Body / Scroll Container */}
            <form onSubmit={(e) => handleCreateSubmit(e, isCreatingInColumn)} className="flex flex-col flex-1 overflow-hidden">
              <div className="p-6 space-y-4 overflow-y-auto max-h-[calc(90vh-140px)]">
                
                {/* 1. Nome do Cliente */}
                <div>
                  <label htmlFor="modal-client-name" className="block text-xs font-bold text-zinc-500 dark:text-zinc-400 uppercase tracking-wider mb-1.5 animate-pulse-once">
                    Nome do Cliente <span className="text-rose-500">*</span>
                  </label>
                  <input
                    id="modal-client-name"
                    type="text"
                    required
                    placeholder="Ex: Carlos Alberto (Morumbi)"
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    className="w-full text-sm p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 text-zinc-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:outline-hidden"
                  />
                </div>

                {/* 2. Projeto / Escopo da Obra */}
                <div>
                  <label htmlFor="modal-project-name" className="block text-xs font-bold text-zinc-500 dark:text-zinc-400 uppercase tracking-wider mb-1.5">
                    Nome do Projeto / Escopo <span className="text-rose-500">*</span>
                  </label>
                  <input
                    id="modal-project-name"
                    type="text"
                    required
                    placeholder="Ex: Reforma Elétrica ou Projeto Luminotécnico Rooftop"
                    value={projectName}
                    onChange={(e) => setProjectName(e.target.value)}
                    className="w-full text-sm p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 text-zinc-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:outline-hidden"
                  />
                </div>

                {/* 3. Contatos (WhatsApp e E-mail) */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="modal-phone" className="block text-xs font-bold text-zinc-500 dark:text-zinc-400 uppercase tracking-wider mb-1.5">
                      WhatsApp / Telefone
                    </label>
                    <input
                      id="modal-phone"
                      type="text"
                      placeholder="Ex: 11999991111"
                      value={contactPhone}
                      onChange={(e) => setContactPhone(e.target.value)}
                      className="w-full text-sm p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 text-zinc-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:outline-hidden"
                    />
                  </div>
                  <div>
                    <label htmlFor="modal-email" className="block text-xs font-bold text-zinc-500 dark:text-zinc-400 uppercase tracking-wider mb-1.5">
                      E-mail do Cliente
                    </label>
                    <input
                      id="modal-email"
                      type="email"
                      placeholder="Ex: carlos@email.com"
                      value={contactEmail}
                      onChange={(e) => setContactEmail(e.target.value)}
                      className="w-full text-sm p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 text-zinc-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:outline-hidden"
                    />
                  </div>
                </div>

                {/* 4. Valores e Margem de Lucro */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="modal-value" className="block text-xs font-bold text-zinc-500 dark:text-zinc-400 uppercase tracking-wider mb-1.5">
                      Valor Bruto do Orçamento (R$)
                    </label>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-zinc-400 font-semibold text-sm">R$</span>
                      <input
                        id="modal-value"
                        type="number"
                        placeholder="Ex: 24000"
                        value={value || ''}
                        onChange={(e) => setValue(Number(e.target.value))}
                        className="w-full text-sm p-2.5 pl-9 rounded-xl bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 text-zinc-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:outline-hidden font-mono"
                      />
                    </div>
                  </div>
                  <div>
                    <label htmlFor="modal-margin" className="block text-xs font-bold text-zinc-500 dark:text-zinc-400 uppercase tracking-wider mb-1.5 flex justify-between items-center">
                      <span>Margem de Lucro (%)</span>
                      {value > 0 && margin > 0 && (
                        <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-extrabold bg-emerald-50 dark:bg-emerald-950/40 px-1.5 py-0.5 rounded-sm normal-case">
                          Ganho: R$ {((value * margin) / 100).toLocaleString('pt-BR', { maximumFractionDigits: 0 })}
                        </span>
                      )}
                    </label>
                    <div className="relative">
                      <input
                        id="modal-margin"
                        type="number"
                        placeholder="Ex: 25"
                        value={margin}
                        onChange={(e) => setMargin(Number(e.target.value))}
                        className="w-full text-sm p-2.5 pr-8 rounded-xl bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 text-zinc-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:outline-hidden font-mono"
                      />
                      <span className="absolute inset-y-0 right-0 pr-3 flex items-center text-zinc-450 font-bold text-sm">%</span>
                    </div>
                  </div>
                </div>

                {/* 5. Prioridade e Responsável */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="modal-priority" className="block text-xs font-bold text-zinc-500 dark:text-zinc-400 uppercase tracking-wider mb-1.5">
                      Prioridade da Cotação
                    </label>
                    <select
                      id="modal-priority"
                      value={priority}
                      onChange={(e) => setPriority(e.target.value as Priority)}
                      className="w-full text-sm p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:outline-hidden cursor-pointer"
                    >
                      <option value="low">Baixa 💡</option>
                      <option value="medium">Média ⏳</option>
                      <option value="high">Alta 🔥</option>
                    </select>
                  </div>
                  <div>
                    <label htmlFor="modal-responsible" className="block text-xs font-bold text-zinc-500 dark:text-zinc-400 uppercase tracking-wider mb-1.5">
                      Responsável / Executor CRM
                    </label>
                    <select
                      id="modal-responsible"
                      value={responsibleId}
                      onChange={(e) => setResponsibleId(e.target.value)}
                      className="w-full text-sm p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:outline-hidden cursor-pointer"
                    >
                      {users.map(u => (
                        <option key={u.id} value={u.id}>{u.name}</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* 6. Fase Atual do Funil e Prazo */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="modal-status" className="block text-xs font-bold text-zinc-500 dark:text-zinc-400 uppercase tracking-wider mb-1.5">
                      Fase do Funil (Status)
                    </label>
                    <select
                      id="modal-status"
                      value={isCreatingInColumn}
                      onChange={(e) => setIsCreatingInColumn(e.target.value as QuoteStatus)}
                      className="w-full text-sm p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:outline-hidden cursor-pointer font-semibold"
                    >
                      {COLUMNS.map(col => (
                        <option key={col.id} value={col.id}>{col.title}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label htmlFor="modal-date" className="block text-xs font-bold text-zinc-500 dark:text-zinc-400 uppercase tracking-wider mb-1.5">
                      Prazo Estimado de Entrega
                    </label>
                    <input
                      id="modal-date"
                      type="date"
                      value={estimatedDate}
                      onChange={(e) => setEstimatedDate(e.target.value)}
                      className="w-full text-sm p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 text-zinc-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:outline-hidden cursor-pointer"
                    />
                  </div>
                </div>

                {/* 7. Descrição Detalhada */}
                <div>
                  <label htmlFor="modal-description" className="block text-xs font-bold text-zinc-500 dark:text-zinc-400 uppercase tracking-wider mb-1.5">
                    Descrição Detalhada do Escopo
                  </label>
                  <textarea
                    id="modal-description"
                    rows={3}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Ex: Instalação de fiação estruturada cat6 nas 12 salas, adequação de disjuntores de entrada..."
                    className="w-full text-sm p-2.5 rounded-xl bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 text-zinc-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 focus:outline-hidden resize-none leading-relaxed"
                  />
                </div>

              </div>

              {/* Modal Footer Actions / Button Bar */}
              <div className="px-6 py-4 bg-zinc-50 dark:bg-zinc-950 border-t border-zinc-200 dark:border-zinc-800 flex justify-end gap-3 rounded-b-2xl">
                <button
                  id="btn-modal-cancel"
                  type="button"
                  onClick={handleCancelCreate}
                  className="px-5 py-2.5 text-xs font-semibold border border-zinc-300 dark:border-zinc-700 text-zinc-700 dark:text-zinc-300 rounded-xl hover:bg-zinc-100 dark:hover:bg-zinc-900 transition-colors cursor-pointer"
                >
                  Desistir
                </button>
                <button
                  id="btn-modal-submit"
                  type="submit"
                  className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-xs text-white font-extrabold rounded-xl shadow-md cursor-pointer transition-colors"
                >
                  Salvar
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
}


