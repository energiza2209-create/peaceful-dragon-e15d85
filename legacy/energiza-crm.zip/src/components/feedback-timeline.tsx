/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { MessageSquare, Plus, Clock, UserCheck, Trash2 } from 'lucide-react';
import { FeedbackLog, User } from '../types';

interface FeedbackTimelineProps {
  feedbacks: FeedbackLog[];
  onAddFeedback: (note: string, createdBy: string) => void;
  onDeleteFeedback?: (id: string) => void;
  users: User[];
  activeUserId: string;
}

export default function FeedbackTimeline({
  feedbacks,
  onAddFeedback,
  onDeleteFeedback,
  users,
  activeUserId,
}: FeedbackTimelineProps) {
  const [noteText, setNoteText] = useState('');
  const [authorId, setAuthorId] = useState(activeUserId);

  const activeUser = users.find(u => u.id === activeUserId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteText.trim()) return;

    const selectedUser = users.find(u => u.id === authorId) || activeUser;
    onAddFeedback(noteText.trim(), selectedUser?.name || 'Sistema');
    setNoteText('');
  };

  // Sort feedbacks chronologically (newest first for comfortable display, or oldest first? Timelines look amazing oldest to newest or newest to oldest. Let's do newest first for immediate interaction visibility)
  const sortedFeedbacks = [...feedbacks].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );

  const formatLogDate = (dateString: string) => {
    const d = new Date(dateString);
    if (isNaN(d.getTime())) return dateString;
    
    return d.toLocaleString('pt-BR', {
      day: '2-digit',
      month: 'short',
      year: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div id="feedback-timeline-module" className="space-y-6">
      {/* Quick Entry Form */}
      <form onSubmit={handleSubmit} className="bg-zinc-50 dark:bg-zinc-800/40 p-4 rounded-xl border border-zinc-200 dark:border-zinc-700/60">
        <label className="block text-xs font-semibold text-zinc-500 dark:text-zinc-400 uppercase tracking-wider mb-2">
          Registrar Novo Feedback / Follow-up
        </label>
        
        <div className="space-y-3">
          <textarea
            id="textarea-feedback-note"
            rows={2}
            value={noteText}
            onChange={(e) => setNoteText(e.target.value)}
            placeholder='Ex: "Cliente achou o valor um pouco acima, mas vai avaliar técnico" ou "Aguardando aprovação das luminárias"'
            className="w-full text-sm bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg p-3 text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 resize-none"
          />

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
            {/* Author Selector */}
            <div className="flex items-center gap-2">
              <span className="text-xs text-zinc-500 dark:text-zinc-400 flex items-center gap-1">
                <UserCheck className="w-3.5 h-3.5" />
                Registrado por:
              </span>
              <div className="flex bg-zinc-100 dark:bg-zinc-800 p-0.5 rounded-md text-xs">
                {users.map((u) => (
                  <button
                    key={u.id}
                    id={`btn-select-author-${u.id}`}
                    type="button"
                    onClick={() => setAuthorId(u.id)}
                    className={`px-2.5 py-1 rounded-md transition-all font-medium ${
                      authorId === u.id
                        ? 'bg-white dark:bg-zinc-700 text-zinc-800 dark:text-white shadow-xs'
                        : 'text-zinc-500 dark:text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-300'
                    }`}
                  >
                    {u.role === 'eu' ? 'Eu 🙋‍♂️' : `${u.name} 🙋‍♀️`}
                  </button>
                ))}
              </div>
            </div>

            {/* Submit Button */}
            <button
              id="btn-submit-feedback"
              type="submit"
              disabled={!noteText.trim()}
              className="px-4 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 disabled:opacity-50 disabled:bg-zinc-400 rounded-lg flex items-center justify-center gap-1.5 self-end sm:self-auto transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              Adicionar
            </button>
          </div>
        </div>
      </form>

      {/* Timeline Stream */}
      <div className="relative pl-6 space-y-6 before:absolute before:top-2 before:bottom-2 before:left-[11px] before:w-0.5 before:bg-zinc-200 dark:before:bg-zinc-700">
        {sortedFeedbacks.length === 0 ? (
          <div className="text-center py-6 text-zinc-400 dark:text-zinc-500 text-xs">
            Nenhuma interação registrada ainda. Use o campo acima para manter o histórico atualizado.
          </div>
        ) : (
          sortedFeedbacks.map((fb, index) => {
            const isWife = fb.createdBy.toLowerCase().includes('esposa') || fb.createdBy.toLowerCase().includes('aline') || fb.createdBy.toLowerCase() === 'ela';
            const initials = fb.createdBy.substring(0, 2).toUpperCase();

            return (
              <div key={fb.id} className="relative group" id={`feedback-item-${fb.id}`}>
                {/* Timeline node */}
                <span className={`absolute -left-[23px] top-1.5 w-[18px] h-[18px] rounded-full border-2 flex items-center justify-center text-[9px] font-bold ${
                  isWife 
                    ? 'bg-rose-50 dark:bg-rose-950 border-rose-500 text-rose-700 dark:text-rose-300' 
                    : 'bg-indigo-50 dark:bg-indigo-950 border-indigo-500 text-indigo-700 dark:text-indigo-300'
                }`}>
                  {initials}
                </span>

                {/* Content */}
                <div className="bg-white dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800/80 rounded-xl p-3 shadow-xs hover:shadow-sm transition-shadow">
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-semibold text-zinc-800 dark:text-zinc-200">
                        {fb.createdBy}
                      </span>
                      <span className="text-[10px] text-zinc-400 dark:text-zinc-500 flex items-center gap-0.5">
                        <Clock className="w-3 h-3" />
                        {formatLogDate(fb.createdAt)}
                      </span>
                    </div>

                    {/* Delete item if developer wants */}
                    {onDeleteFeedback && (
                      <button
                        id={`btn-delete-feedback-${fb.id}`}
                        onClick={() => onDeleteFeedback(fb.id)}
                        className="opacity-0 group-hover:opacity-100 text-zinc-400 hover:text-rose-500 p-1 rounded-md transition-all"
                        title="Deletar este registro"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  <p className="text-sm text-zinc-600 dark:text-zinc-300 whitespace-pre-line leading-relaxed">
                    {fb.note}
                  </p>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
