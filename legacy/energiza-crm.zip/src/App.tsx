/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Plus, MessageSquare, Sparkles, Database, 
  HelpCircle, User, Moon, Sun, Laptop, 
  Layers, LayoutDashboard, Briefcase, Menu, X,
  Zap, Cloud, CloudLightning, RefreshCw, AlertCircle,
  Kanban
} from 'lucide-react';

import { Quote, FeedbackLog, Insight, QuoteStatus, Priority, User as CRMUser, InsightCategory } from './types';
import Dashboard from './components/dashboard';
import KanbanBoard from './components/kanban';
import InsightsModule from './components/insights';
import DatabaseSchema from './components/database-schema';
import QuoteDetailsModal from './components/quote-details-modal';
import { getSupabaseConfig, syncDataToSupabase, pullDataFromSupabase, deleteQuoteFromSupabase, deleteFeedbackFromSupabase, deleteInsightFromSupabase } from './lib/supabase';

// Define the two owners
const USERS: CRMUser[] = [
  { id: 'user-1', name: 'Matheus (Eu)', avatar: '🙋‍♂️', role: 'eu' },
  { id: 'user-2', name: 'Nara Rubia (Ela)', avatar: '🙋‍♀️', role: 'ela' },
];

// Initial seed data to make the experience instant
const SEED_QUOTES: Quote[] = [
  {
    id: 'quote-1',
    clientName: 'Carlos Alberto (Morumbi)',
    projectName: 'Reforma Residencial Morumbi',
    contactPhone: '11999991111',
    contactEmail: 'carlos.alberto@email.com',
    description: 'Reforma completa do living principal, incluindo instalação de sanca de gesso com fita LED RGB, automação de cortinas e adequação de tomadas.',
    value: 24000,
    margin: 25,
    estimatedDate: '2026-06-25',
    createdAt: new Date(Date.now() - 4 * 24 * 3600 * 1000).toISOString(), // 4 days ago
    updatedAt: new Date(Date.now() - 4 * 24 * 3600 * 1000).toISOString(),
    status: 'analysis',
    priority: 'high',
    responsibleId: 'user-1',
  },
  {
    id: 'quote-2',
    clientName: 'Mariana Mendes',
    projectName: 'Projeto Luminotécnico Rooftop',
    contactPhone: '11988882222',
    contactEmail: 'mariana.mendes@email.com',
    description: 'Consultoria e entrega de projeto elétrico e luminotécnico para varanda gourmet e cobertura duplex em Pinheiros.',
    value: 7305,
    margin: 35,
    estimatedDate: '2026-06-30',
    createdAt: new Date(Date.now() - 5 * 24 * 3600 * 1000).toISOString(), // 5 days ago (triggers >3 days Alert as no feedback was inserted since)
    updatedAt: new Date(Date.now() - 5 * 24 * 3600 * 1000).toISOString(),
    status: 'sent',
    priority: 'medium',
    responsibleId: 'user-2',
  },
  {
    id: 'quote-3',
    clientName: 'Síndico Marcos',
    projectName: 'Manutenção Elétrica Condomínio',
    contactPhone: '11977773333',
    contactEmail: 'marcos.sindico@email.com',
    description: 'Adequação de barramento blindado de distribuição, troca de disjuntores gerais no quadro de forças e para-raios predial.',
    value: 9500,
    margin: 40,
    estimatedDate: '2026-06-20',
    createdAt: new Date(Date.now() - 12 * 24 * 3600 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 2 * 24 * 3600 * 1000).toISOString(),
    status: 'won',
    priority: 'high',
    responsibleId: 'user-1',
  },
  {
    id: 'quote-4',
    clientName: 'Dr. Roberto',
    projectName: 'Adequação Elétrica AP 42',
    contactPhone: '11966664444',
    contactEmail: 'roberto.med@email.com',
    description: 'Instalação de circuito independente para carregador de veículo elétrico Wallbox na garagem e substituição do quadro de distribuição antigo.',
    value: 5800,
    margin: 18,
    estimatedDate: '2026-06-18',
    createdAt: new Date(Date.now() - 1 * 24 * 3600 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
    status: 'negotiation',
    priority: 'low',
    responsibleId: 'user-2',
  },
  {
    id: 'quote-5',
    clientName: 'Eng. Cláudio Santos',
    projectName: 'Consultoria NR10 Galpão',
    contactPhone: '21955555555',
    contactEmail: 'claudio@santosconstrucoes.com.m',
    description: 'Laudo técnico eletromecânico e adequação de segurança NR10 para galpão industrial de estocagem fria.',
    value: 12000,
    margin: 30,
    estimatedDate: '2026-07-15',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    status: 'new',
    priority: 'high',
    responsibleId: 'user-1',
  },
  {
    id: 'quote-6',
    clientName: 'Dra. Heloísa',
    projectName: 'Climatização Duplex Panamby',
    contactPhone: '11944446666',
    contactEmail: 'heloisa.panamby@email.com',
    description: 'Dimensionamento térmico e instalação de ar condicionado central multi-split dutado em cobertura recém-comprada.',
    value: 35000,
    margin: 20,
    estimatedDate: '2026-06-01',
    createdAt: new Date(Date.now() - 20 * 24 * 3600 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 10 * 24 * 3600 * 1000).toISOString(),
    status: 'lost',
    priority: 'high',
    responsibleId: 'user-2',
    lossReason: 'price',
    lossDetails: 'O concorrente ofereceu o mesmo projeto com 15% de desconto no pix e facilitou o pagamento no boleto.',
  }
];

const SEED_FEEDBACKS: FeedbackLog[] = [
  {
    id: 'fb-1',
    quoteId: 'quote-3',
    note: 'Visita técnica realizada para entender os disjuntores da cabine primária. Síndico aprovou a rapidez do envio técnico.',
    createdBy: 'Matheus (Eu)',
    createdAt: new Date(Date.now() - 11 * 24 * 365 * 1000).toISOString(),
  },
  {
    id: 'fb-2',
    quoteId: 'quote-3',
    note: 'Contrato técnico assinado e 1ª parcela de R$ 4.750,00 faturada e paga pelo condomínio com sucesso!',
    createdBy: 'Nara Rubia (Ela)',
    createdAt: new Date(Date.now() - 2 * 24 * 3600 * 1000).toISOString(),
  },
  {
    id: 'fb-3',
    quoteId: 'quote-4',
    note: 'Cliente achou o valor da fiação um pouco elevado, pediu alternativas de bitolas ou cabo mais econômico. Nara Rubia respondeu esclarecendo a segurança.',
    createdBy: 'Nara Rubia (Ela)',
    createdAt: new Date(Date.now() - 1 * 24 * 3600 * 1000).toISOString(),
  },
];

const SEED_INSIGHTS: Insight[] = [
  {
    id: 'ins-1',
    title: 'Atacar nicho de automação para lofts residenciais de alto padrão',
    description: 'A construtora Cyrela está entregando 3 empreendimentos novos em Pinheiros e Vila Madalena com perfis perfeitos para pacotes completos de áudio, iluminação inteligente e cortinas automáticas.',
    category: 'nicho',
    createdBy: 'Nara Rubia',
    createdAt: new Date(Date.now() - 3 * 24 * 3600 * 1000).toISOString(),
  },
  {
    id: 'ins-2',
    title: 'Fornecedor de Fitas de LED no atacado na Santa Ifigênia',
    description: 'Contatar a distribuidora "Luz & Arte". Falar com Wellington no telefone (11) 98765-4321. Eles dão desconto de 25% para compras acima de 12 rolos de 5m de fitas de COB 24V.',
    category: 'supplier',
    createdBy: 'Matheus',
    createdAt: new Date(Date.now() - 1 * 24 * 3600 * 1000).toISOString(),
  },
  {
    id: 'ins-3',
    title: 'Melhoria: Enviar os orçamentos com PDF customizado para simular luxo',
    description: 'Montar um modelo elegante no Canva para colocarmos os valores finais de projetos de mais de R$ 15.000,00. Propostas bem diagramadas ajudam o cliente de alta renda a validar a margem.',
    category: 'improvement',
    createdBy: 'Matheus',
    createdAt: new Date().toISOString(),
  },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'kanban' | 'insights' | 'schema'>('dashboard');
  const [themeMode, setThemeMode] = useState<'light' | 'dark'>('dark');
  const [activeUserId, setActiveUserId] = useState<string>('user-1');
  
  // Responsive mobile menu state
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Core CRM data state
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const [feedbacks, setFeedbacks] = useState<FeedbackLog[]>([]);
  const [insights, setInsights] = useState<Insight[]>([]);

  // Sub-navigation prefilled hooks (Seamless insights-to-quotes adapter)
  const [prefillProject, setPrefillProject] = useState('');
  const [prefillDesc, setPrefillDesc] = useState('');

  // Selected quote in Modal detail handler
  const [selectedQuote, setSelectedQuote] = useState<Quote | null>(null);

  // Cloud Sync Status Tracking State
  const [cloudSyncStatus, setCloudSyncStatus] = useState<'synced' | 'syncing' | 'offline' | 'error'>('offline');
  const [isInitialLoadCompleted, setIsInitialLoadCompleted] = useState(false);

  // Initialize and load datasets (Offline load + Smart automatic startup Pull)
  useEffect(() => {
    // Read theme mode
    const storedTheme = localStorage.getItem('duocrm-theme');
    if (storedTheme === 'light' || storedTheme === 'dark') {
      setThemeMode(storedTheme);
    }

    // Read active user
    const storedUser = localStorage.getItem('duocrm-active-user-id');
    if (storedUser) {
      setActiveUserId(storedUser);
    }

    // Load local cache as instant placeholder, so the app feels lightning fast
    const storedQuotes = localStorage.getItem('duocrm-quotes');
    const storedFeedbacks = localStorage.getItem('duocrm-feedbacks');
    const storedInsights = localStorage.getItem('duocrm-insights');

    let initialQuotesList = SEED_QUOTES;
    let initialFeedbacksList = SEED_FEEDBACKS;
    let initialInsightsList = SEED_INSIGHTS;

    if (storedQuotes) {
      try {
        initialQuotesList = JSON.parse(storedQuotes);
      } catch (e) {
        console.error('Falha ao decodificar cotações locais:', e);
      }
    }
    if (storedFeedbacks) {
      try {
        initialFeedbacksList = JSON.parse(storedFeedbacks);
      } catch (e) {
        console.error('Falha ao decodificar feedbacks locais:', e);
      }
    }
    if (storedInsights) {
      try {
        initialInsightsList = JSON.parse(storedInsights);
      } catch (e) {
        console.error('Falha ao decodificar insights locais:', e);
      }
    }

    // Apply local cache first so it renders instantly
    setQuotes(initialQuotesList);
    setFeedbacks(initialFeedbacksList);
    setInsights(initialInsightsList);

    // Smart Auto Pull: Check if Supabase configuration is set in the client browser
    const config = getSupabaseConfig();
    if (config) {
      setCloudSyncStatus('syncing');
      
      pullDataFromSupabase()
        .then((res) => {
          if (res.success) {
            // Found active data in Supabase Cloud! Sync everything to override local cache
            setQuotes(res.quotes);
            setFeedbacks(res.feedbacks);
            setInsights(res.insights);
            
            localStorage.setItem('duocrm-quotes', JSON.stringify(res.quotes));
            localStorage.setItem('duocrm-feedbacks', JSON.stringify(res.feedbacks));
            localStorage.setItem('duocrm-insights', JSON.stringify(res.insights));
            
            setCloudSyncStatus('synced');
          } else {
            // Failed or empty cloud (e.g. initial setup) - preserve local caches
            console.log('Sem dados remotos ou tabelas em branco. Preservando modo offline:', res.message);
            setCloudSyncStatus('synced'); // Mark as synced representing local master
          }
          setIsInitialLoadCompleted(true);
        })
        .catch((err) => {
          console.error('Falha de conexão com no auto pull:', err);
          setIsInitialLoadCompleted(true);
          setCloudSyncStatus('error');
        });
    } else {
      // Offline mode
      setCloudSyncStatus('offline');
      setIsInitialLoadCompleted(true);
    }
  }, []);

  // Smart Auto-Push: Background save triggered debounced by 1.5 seconds on subsequent updates
  useEffect(() => {
    if (!isInitialLoadCompleted) return;

    const config = getSupabaseConfig();
    if (!config) {
      setCloudSyncStatus('offline');
      return;
    }

    setCloudSyncStatus('syncing');
    
    // Debounce the cloud integration push to prevent overloading Supabase API rate limits
    const delayDebouncer = setTimeout(() => {
      syncDataToSupabase(quotes, feedbacks, insights)
        .then((res) => {
          if (res.success) {
            setCloudSyncStatus('synced');
          } else {
            console.error('Erro no salvamento automático:', res.message);
            setCloudSyncStatus('error');
          }
        })
        .catch((err) => {
          console.error('Falha crítica de sincrono de dados:', err);
          setCloudSyncStatus('error');
        });
    }, 1500);

    return () => clearTimeout(delayDebouncer);
  }, [quotes, feedbacks, insights, isInitialLoadCompleted]);

  // Sync quotes to local storage
  const syncQuotes = (newQuotes: Quote[]) => {
    setQuotes(newQuotes);
    localStorage.setItem('duocrm-quotes', JSON.stringify(newQuotes));

    // Update selected quote if it matches
    if (selectedQuote) {
      const fresh = newQuotes.find(q => q.id === selectedQuote.id);
      if (fresh) setSelectedQuote(fresh);
    }
  };

  // Sync feedbacks to local storage
  const syncFeedbacks = (newFeedbacks: FeedbackLog[]) => {
    setFeedbacks(newFeedbacks);
    localStorage.setItem('duocrm-feedbacks', JSON.stringify(newFeedbacks));
  };

  // Sync insights to local storage
  const syncInsights = (newInsights: Insight[]) => {
    setInsights(newInsights);
    localStorage.setItem('duocrm-insights', JSON.stringify(newInsights));
  };

  // Helper for instantaneous background pushes to bypass debouncing on critical mutations
  const triggerInstantPush = (
    currentQuotes: Quote[],
    currentFeedbacks: FeedbackLog[],
    currentInsights: Insight[]
  ) => {
    const config = getSupabaseConfig();
    if (!config) return;

    setCloudSyncStatus('syncing');
    syncDataToSupabase(currentQuotes, currentFeedbacks, currentInsights)
      .then((res) => {
        if (res.success) {
          setCloudSyncStatus('synced');
        } else {
          console.error('Erro no sincronismo instantâneo de dados:', res.message);
          setCloudSyncStatus('error');
        }
      })
      .catch((err) => {
        console.error('Falha de sincrono imediato:', err);
        setCloudSyncStatus('error');
      });
  };

  // Toggle visual theme class directly on layout body
  useEffect(() => {
    const rootElement = document.documentElement;
    if (themeMode === 'dark') {
      rootElement.classList.add('dark');
      rootElement.style.colorScheme = 'dark';
    } else {
      rootElement.classList.remove('dark');
      rootElement.style.colorScheme = 'light';
    }
    localStorage.setItem('duocrm-theme', themeMode);
  }, [themeMode]);

  // Handle active user selector
  const handleUserChange = (id: string) => {
    setActiveUserId(id);
    localStorage.setItem('duocrm-active-user-id', id);
  };

  // Action: Add Quote
  const handleAddQuote = (newQuoteData: Omit<Quote, 'id' | 'createdAt' | 'updatedAt'>) => {
    const fresh: Quote = {
      ...newQuoteData,
      id: 'quote-' + Math.random().toString(36).substring(2, 11),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    
    const updatedList = [fresh, ...quotes];
    syncQuotes(updatedList);

    // Auto-create initial follow-up about creation
    const freshFeedback: FeedbackLog = {
      id: 'fb-' + Math.random().toString(36).substring(2, 11),
      quoteId: fresh.id,
      note: `Cotação cadastrada no sistema sob a responsabilidade de ${USERS.find(u => u.id === newQuoteData.responsibleId)?.name}.`,
      createdBy: 'Sistema',
      createdAt: new Date().toISOString(),
    };
    const updatedFeedbacks = [freshFeedback, ...feedbacks];
    syncFeedbacks(updatedFeedbacks);

    triggerInstantPush(updatedList, updatedFeedbacks, insights);
  };

  // Action: Update Quote
  const handleUpdateQuote = (updatedQuote: Quote) => {
    const updatedList = quotes.map(q => q.id === updatedQuote.id ? updatedQuote : q);
    syncQuotes(updatedList);
    triggerInstantPush(updatedList, feedbacks, insights);
  };

  // Action: Delete Quote
  const handleDeleteQuote = (id: string) => {
    const updatedList = quotes.filter(q => q.id !== id);
    const updatedFeedbacks = feedbacks.filter(f => f.quoteId !== id);
    syncQuotes(updatedList);
    syncFeedbacks(updatedFeedbacks);
    setSelectedQuote(null);
    
    // Immediate, explicit deletion on Supabase
    const config = getSupabaseConfig();
    if (config) {
      setCloudSyncStatus('syncing');
      deleteQuoteFromSupabase(id)
        .then((res) => {
          if (res.success) {
            setCloudSyncStatus('synced');
          } else {
            console.error('Erro ao excluir cotação na nuvem:', res.message);
            setCloudSyncStatus('error');
          }
        })
        .catch((err) => {
          console.error('Falha crítica de conexão ao excluir cotação:', err);
          setCloudSyncStatus('error');
        });
    } else {
      triggerInstantPush(updatedList, updatedFeedbacks, insights);
    }
  };

  // Action: Add Feedback Follow-up
  const handleAddFeedback = (quoteId: string, note: string, createdBy: string) => {
    const fresh: FeedbackLog = {
      id: 'fb-' + Math.random().toString(36).substring(2, 11),
      quoteId,
      note,
      createdBy,
      createdAt: new Date().toISOString(),
    };
    const updatedList = [fresh, ...feedbacks];
    syncFeedbacks(updatedList);
    triggerInstantPush(quotes, updatedList, insights);
  };

  // Action: Delete Feedback Follow-up
  const handleDeleteFeedback = (id: string) => {
    const updatedList = feedbacks.filter(f => f.id !== id);
    syncFeedbacks(updatedList);
    
    // Immediate, explicit deletion on Supabase
    const config = getSupabaseConfig();
    if (config) {
      setCloudSyncStatus('syncing');
      deleteFeedbackFromSupabase(id)
        .then((res) => {
          if (res.success) {
            setCloudSyncStatus('synced');
          } else {
            console.error('Erro ao excluir feedback na nuvem:', res.message);
            setCloudSyncStatus('error');
          }
        })
        .catch((err) => {
          console.error('Falha de conexão ao excluir feedback:', err);
          setCloudSyncStatus('error');
        });
    } else {
      triggerInstantPush(quotes, updatedList, insights);
    }
  };

  // Action: Add Insight
  const handleAddInsight = (title: string, description: string, category: InsightCategory, createdBy: string) => {
    const fresh: Insight = {
      id: 'ins-' + Math.random().toString(36).substring(2, 11),
      title,
      description,
      category,
      createdBy,
      createdAt: new Date().toISOString(),
    };
    const updatedList = [fresh, ...insights];
    syncInsights(updatedList);
    triggerInstantPush(quotes, feedbacks, updatedList);
  };

  // Action: Delete Insight
  const handleDeleteInsight = (id: string) => {
    const updatedList = insights.filter(i => i.id !== id);
    syncInsights(updatedList);
    
    // Immediate, explicit deletion on Supabase
    const config = getSupabaseConfig();
    if (config) {
      setCloudSyncStatus('syncing');
      deleteInsightFromSupabase(id)
        .then((res) => {
          if (res.success) {
            setCloudSyncStatus('synced');
          } else {
            console.error('Erro ao excluir insight na nuvem:', res.message);
            setCloudSyncStatus('error');
          }
        })
        .catch((err) => {
          console.error('Falha de conexão ao excluir insight:', err);
          setCloudSyncStatus('error');
        });
    } else {
      triggerInstantPush(quotes, feedbacks, updatedList);
    }
  };

  // Custom Integration flow: Converting an insight into a true Quote
  const handleConvertInsightToQuote = (insight: Insight) => {
    // Fill pre-populated items
    setPrefillProject(insight.title);
    setPrefillDesc(`Ideia originalmente documentada no inbox por ${insight.createdBy}:\n"${insight.description}"`);
    
    // Flag converted on insight
    const updatedInsights = insights.map(i => i.id === insight.id ? { ...i, convertedToQuoteId: 'pending' } : i);
    syncInsights(updatedInsights);

    // Switch view to Kanban board
    setActiveTab('kanban');
    setMobileMenuOpen(false);
  };

  // Clear transition configs
  const handleClearPrefills = () => {
    setPrefillProject('');
    setPrefillDesc('');
  };

  const activeUser = USERS.find(u => u.id === activeUserId) || USERS[0];

  return (
    <div className={`min-h-screen transition-colors duration-150 font-sans flex flex-col bg-zinc-100 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-100`}>
      
      {/* Dynamic Upper Banner / Active User Role Indicator */}
      <div className="bg-zinc-900 dark:bg-black px-4 py-2.5 border-b border-zinc-800 dark:border-zinc-900 flex justify-between items-center sm:px-6 transition-colors duration-150 shadow-xs">
        <div className="flex items-center gap-2">
          <Zap className="w-4 h-4 text-amber-400 animate-[pulse_2s_infinite] shrink-0" />
          <span className="text-zinc-200 text-xs font-semibold tracking-wide">
            Energiza Executivo: <span className="font-extrabold text-white text-sm bg-zinc-800 px-2 py-0.5 rounded-md border border-zinc-700/60 ml-1">{activeUser.name}</span>
          </span>
        </div>
        
        {/* Rapid user role selection tool */}
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-zinc-400 font-extrabold uppercase hidden md:inline tracking-wider">Operado por:</span>
          <div className="flex bg-zinc-800 p-0.5 rounded-lg text-xs border border-zinc-700/60">
            {USERS.map(u => (
              <button
                key={u.id}
                id={`btn-user-switch-app-${u.id}`}
                onClick={() => handleUserChange(u.id)}
                className={`px-3 py-1 rounded-md font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  activeUserId === u.id
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-zinc-300 hover:text-white hover:bg-zinc-700/40'
                }`}
              >
                <span className="text-sm">{u.avatar}</span>
                <span>{u.name.replace(' (Eu)', '').replace(' (Ela)', '')}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Header / Navigation */}
      <header className="bg-white dark:bg-zinc-950 border-b border-zinc-200 dark:border-zinc-900 sticky top-0 z-40 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          
          {/* Branded Title Section */}
          <div className="flex items-center gap-2.5">
            <span className="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center text-white shadow-md shadow-orange-500/10 ring-2 ring-amber-400/25 transition-all transform hover:scale-105 duration-200">
              <Zap className="w-5.5 h-5.5 text-white fill-amber-350 animate-pulse" />
            </span>
            <div>
              <h1 className="text-base font-black text-zinc-900 dark:text-white leading-none tracking-tight">Energiza CRM</h1>
              <p className="text-[9px] font-extrabold text-amber-600 dark:text-amber-400 uppercase mt-1.5 tracking-widest leading-none">
                M&N • Matheus & Nara Rubia
              </p>
            </div>
          </div>

          {/* Nav Links - Desktop (Tabs switcher) */}
          <nav className="hidden md:flex bg-zinc-100 dark:bg-zinc-900/80 p-1 rounded-xl">
            {(['dashboard', 'kanban', 'insights', 'schema'] as const).map((tab) => {
              const labels = {
                dashboard: 'Dashboard',
                kanban: 'Funil Kanban',
                insights: 'Ideias/Outros',
                schema: 'Engenharia/DB',
              };
              const icons = {
                dashboard: LayoutDashboard,
                kanban: Kanban,
                insights: Sparkles,
                schema: Database,
              };
              const IconComponent = icons[tab];
              
              return (
                <button
                  key={tab}
                  id={`nav-tab-${tab}`}
                  onClick={() => setActiveTab(tab)}
                  className={`px-4 py-2 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-all text-left cursor-pointer ${
                    activeTab === tab
                      ? 'bg-white dark:bg-zinc-800 text-indigo-600 dark:text-white shadow-xs'
                      : 'text-zinc-650 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200'
                  }`}
                >
                  <IconComponent className="w-4 h-4 shrink-0" />
                  {labels[tab]}
                </button>
              );
            })}
          </nav>

          {/* Right Header Options (Theme switch, Mobile trigger) */}
          <div className="flex items-center gap-3">
            
            {/* Live Cloud Status Indicator */}
            <div 
              id="cloud-sync-header-pill" 
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900 text-[10px] md:text-[11px] cursor-help"
              title="A sincronia com o Supabase é totalmente automática!"
            >
              {cloudSyncStatus === 'synced' && (
                <>
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-[pulse_3s_infinite] shrink-0" />
                  <span className="font-extrabold text-zinc-700 dark:text-zinc-300">Nuvem Ativa</span>
                </>
              )}
              {cloudSyncStatus === 'syncing' && (
                <>
                  <RefreshCw className="w-3 h-3 text-amber-500 animate-spin shrink-0" />
                  <span className="font-extrabold text-amber-600 dark:text-amber-400">Gravando...</span>
                </>
              )}
              {cloudSyncStatus === 'offline' && (
                <>
                  <span className="w-2 h-2 rounded-full bg-zinc-400 shrink-0" />
                  <span className="font-bold text-zinc-400">Master Local</span>
                </>
              )}
              {cloudSyncStatus === 'error' && (
                <>
                  <AlertCircle className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                  <span className="font-black text-rose-500">Erro de Sincronia</span>
                </>
              )}
            </div>

            {/* Visual Lights Toggle */}
            <button
              id="theme-toggler"
              onClick={() => setThemeMode(themeMode === 'light' ? 'dark' : 'light')}
              className="p-2 border border-zinc-200 dark:border-zinc-800 text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-white rounded-xl bg-zinc-50 dark:bg-zinc-900 shadow-xs cursor-pointer"
              title="Alternar Tema Escuro/Claro"
            >
              {themeMode === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4 text-amber-400 animate-pulse" />}
            </button>

            {/* Mobile Nav toggle button */}
            <button
              id="mobile-nav-toggle"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-zinc-500 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-900 border border-zinc-200 dark:border-zinc-900 rounded-xl"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>

        </div>

        {/* Mobile Navigation Dropdown view */}
        {mobileMenuOpen && (
          <nav className="md:hidden border-t border-zinc-100 dark:border-zinc-900 bg-white dark:bg-zinc-950 p-4 space-y-2 text-left animate-slide-down">
            {(['dashboard', 'kanban', 'insights', 'schema'] as const).map((tab) => {
              const labels = {
                dashboard: '📊 Dashboard Geral',
                kanban: '📋 Funil de Cotações (Kanban)',
                insights: '💡 Inbox de Ideias / Fornecedores',
                schema: '⚙ Definição do Banco (Schema)',
              };
              
              return (
                <button
                  key={tab}
                  id={`mobile-tab-${tab}`}
                  onClick={() => {
                    setActiveTab(tab);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full p-3 text-sm font-semibold rounded-xl flex items-center transition-all ${
                    activeTab === tab
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'text-zinc-750 dark:text-zinc-400 hover:bg-zinc-50 dark:hover:bg-zinc-900'
                  }`}
                >
                  {labels[tab]}
                </button>
              );
            })}
          </nav>
        )}
      </header>

      {/* Main CRM Application Stage */}
      <main className={`flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 ${activeTab === 'kanban' ? 'pt-4 pb-1' : 'py-8'}`}>
        
        {/* Core dynamic tabs routing */}
        {activeTab === 'dashboard' && (
          <Dashboard 
            quotes={quotes}
            feedbacks={feedbacks}
            users={USERS}
            onSelectQuote={setSelectedQuote}
          />
        )}

        {activeTab === 'kanban' && (
          <KanbanBoard 
            quotes={quotes}
            feedbacks={feedbacks}
            users={USERS}
            onUpdateQuote={handleUpdateQuote}
            onAddQuote={handleAddQuote}
            onSelectQuote={setSelectedQuote}
            activeUserId={activeUserId}
            prefillNewQuoteProject={prefillProject}
            prefillNewQuoteDesc={prefillDesc}
            onClearPrefills={handleClearPrefills}
          />
        )}

        {activeTab === 'insights' && (
          <InsightsModule 
            insights={insights}
            onAddInsight={handleAddInsight}
            onDeleteInsight={handleDeleteInsight}
            onConvertToQuote={handleConvertInsightToQuote}
            users={USERS}
            activeUserId={activeUserId}
          />
        )}

        {activeTab === 'schema' && (
          <DatabaseSchema 
            quotes={quotes}
            feedbacks={feedbacks}
            insights={insights}
            onReloadAllData={(updatedQuotes, updatedFeedbacks, updatedInsights) => {
              setQuotes(updatedQuotes);
              setFeedbacks(updatedFeedbacks);
              setInsights(updatedInsights);
              localStorage.setItem('duocrm-quotes', JSON.stringify(updatedQuotes));
              localStorage.setItem('duocrm-feedbacks', JSON.stringify(updatedFeedbacks));
              localStorage.setItem('duocrm-insights', JSON.stringify(updatedInsights));
            }}
          />
        )}

      </main>

      {/* RENDER MODAL IN TOP PORTAL LAYER (Active Detail & Timeline Logger) */}
      {selectedQuote && (
        <QuoteDetailsModal 
          quote={selectedQuote}
          onClose={() => setSelectedQuote(null)}
          onUpdateQuote={handleUpdateQuote}
          onDeleteQuote={handleDeleteQuote}
          feedbacks={feedbacks}
          onAddFeedback={handleAddFeedback}
          onDeleteFeedback={handleDeleteFeedback}
          users={USERS}
          activeUserId={activeUserId}
        />
      )}



    </div>
  );
}
