/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Priority = 'high' | 'medium' | 'low';

export type QuoteStatus = 
  | 'new'          // Nova Cotação / Triagem
  | 'analysis'     // Em Análise / Elaboração
  | 'sent'         // Enviada / Aguardando Resposta
  | 'negotiation'  // Negociação / Ajustes
  | 'won'          // Ganha (Sucesso)
  | 'lost';        // Perdida / Cancelada

export type InsightCategory = 'improvement' | 'nicho' | 'supplier'| 'other';

export interface User {
  id: string;
  name: string;
  avatar: string;
  role: 'eu' | 'ela';
}

export interface Quote {
  id: string;
  clientName: string;
  projectName: string;
  contactPhone: string; // WhatsApp
  contactEmail: string;
  description: string;
  value: number;
  margin: number;       // Margem de lucro estimada (%)
  estimatedDate: string; // Prazo de entrega
  createdAt: string;
  updatedAt: string;
  status: QuoteStatus;
  priority: Priority;
  responsibleId: string; // ID of the User
  lossReason?: 'price' | 'deadline' | 'competitor' | 'vanished' | 'other';
  lossDetails?: string;
}

export interface FeedbackLog {
  id: string;
  quoteId: string;
  note: string;
  createdBy: string; // User Name or ID
  createdAt: string;
}

export interface Insight {
  id: string;
  title: string;
  description: string;
  category: InsightCategory;
  createdBy: string; // User Name or ID
  createdAt: string;
  convertedToQuoteId?: string; // If this insight became a quote
}

// Columns configuration structure
export interface KanbanColumn {
  id: QuoteStatus;
  title: string;
  color: string; // Tailwind border/bg indicator color
}
