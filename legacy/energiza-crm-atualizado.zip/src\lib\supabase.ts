import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { Quote, FeedbackLog, Insight } from '../types';

export interface SupabaseConfig {
  url: string;
  anonKey: string;
}

// Get config from localStorage or env
export function getSupabaseConfig(): SupabaseConfig | null {
  // Check localStorage first for runtime changes without redeploying
  const localUrl = localStorage.getItem('supabase_url');
  const localKey = localStorage.getItem('supabase_anon_key');

  if (localUrl && localKey) {
    return { url: localUrl, anonKey: localKey };
  }

  // Fallback to bundler environment variables
  const envUrl = (import.meta as any).env?.VITE_SUPABASE_URL;
  const envKey = (import.meta as any).env?.VITE_SUPABASE_ANON_KEY;

  if (envUrl && envKey) {
    return { url: envUrl, anonKey: envKey };
  }

  // Pre-configured default credentials provided by the user for automatic sync
  const defaultUrl = 'https://fhjihlndqfzzcqwoijmj.supabase.co';
  const defaultKey = 'sb_publishable_xVVI4WzaOUt9YoXvgFCHTw_M_2SZp5k';
  
  if (defaultUrl && defaultKey) {
    return { url: defaultUrl, anonKey: defaultKey };
  }

  return null;
}

export function saveSupabaseConfig(url: string, anonKey: string) {
  if (!url || !anonKey) return;
  localStorage.setItem('supabase_url', url.trim());
  localStorage.setItem('supabase_anon_key', anonKey.trim());
}

export function clearSupabaseConfig() {
  localStorage.removeItem('supabase_url');
  localStorage.removeItem('supabase_anon_key');
}

// Lazy initialization of active Supabase Client
let cachedClient: SupabaseClient | null = null;

export function getSupabaseClient(): SupabaseClient | null {
  const config = getSupabaseConfig();
  if (!config) {
    cachedClient = null;
    return null;
  }
  
  // Re-instantiate if config changed or not set
  if (!cachedClient) {
    try {
      cachedClient = createClient(config.url, config.anonKey, {
        auth: { persistSession: false }
      });
    } catch (err) {
      console.error('Falha de inicialização do Supabase:', err);
      return null;
    }
  }
  
  return cachedClient;
}

export async function testSupabaseConnection(url: string, anonKey: string): Promise<{ success: boolean; message: string }> {
  try {
    const client = createClient(url, anonKey, { auth: { persistSession: false } });
    
    // Attempt a lightweight command on any standard metadata route or user schema
    // In Supabase, testing with a standard auth.getSession() or basic query is safe and fast.
    const { error } = await client.from('User').select('count', { count: 'exact', head: true }).limit(1);
    
    // If table doesn't exist yet, that's still a success because we connected to Supabase!
    // The only errors that indicate failure to connect are network, CORS, or incorrect secrets (Invalid API key/Invalid URL)
    if (error && (error.message.includes('Invalid API key') || error.message.includes('FetchError') || error.message.includes('failed to fetch'))) {
      return { success: false, message: `Erro de Conexão: ${error.message}` };
    }
    
    return { success: true, message: 'Conectado com sucesso ao banco Supabase!' };
  } catch (err: any) {
    return { success: false, message: err?.message || 'Falha de rede ao conectar.' };
  }
}

/**
 * Synchronize local data arrays directly to Supabase tables
 * It uses upsert queries so it's repeating-safe!
 */
export async function syncDataToSupabase(
  quotes: Quote[],
  feedbacks: FeedbackLog[],
  insights: Insight[]
): Promise<{ success: boolean; quoteCount: number; feedbackCount: number; insightCount: number; message: string }> {
  const client = getSupabaseClient();
  if (!client) {
    return { success: false, quoteCount: 0, feedbackCount: 0, insightCount: 0, message: 'Supabase não está configurado.' };
  }

  try {
    // 1. Sync User profiles first
    const users = [
      { id: 'user-1', name: 'Matheus (Eu)', avatar: '🙋‍♂️', role: 'eu' },
      { id: 'user-2', name: 'Nara Rubia (Ela)', avatar: '🙋‍♀️', role: 'ela' }
    ];
    
    try {
      const { error: userErr } = await client.from('User').upsert(users);
      if (userErr) throw new Error(`Falha ao sincronizar Usuários: ${userErr.message}`);
    } catch (e: any) {
      if (e.message?.includes('Failed to fetch') || e.message?.includes('failed to fetch')) {
        throw new Error('Falha de rede (Failed to fetch) ao salvar Usuários. Verifique se há algum bloqueador de anúncios/rastreamento (AdBlock/Brave Shields) ativo bloqueando as requisições do Supabase.');
      }
      throw e;
    }

    // 2. Sync Quotes
    const mappedQuotes = quotes.map(q => ({
      id: q.id,
      clientName: q.clientName,
      projectName: q.projectName,
      contactPhone: q.contactPhone,
      contactEmail: q.contactEmail,
      description: q.description,
      value: q.value,
      margin: q.margin,
      estimatedDate: q.estimatedDate ? new Date(q.estimatedDate).toISOString() : null,
      status: q.status,
      priority: q.priority,
      responsibleId: q.responsibleId,
      lossReason: q.lossReason || null,
      lossDetails: q.lossDetails || null,
      supplierLinks: q.supplierLinks || [],
      productPhotos: q.productPhotos || [],
      technicalProposal: q.technicalProposal || null,
      commercialProposal: q.commercialProposal || null,
      createdAt: q.createdAt,
      updatedAt: q.updatedAt
    }));

    try {
      const { error: quoteErr } = await client.from('Quote').upsert(mappedQuotes);
      if (quoteErr) throw new Error(`Falha ao sincronizar Cotações: ${quoteErr.message}`);
    } catch (e: any) {
      if (e.message?.includes('Failed to fetch') || e.message?.includes('failed to fetch')) {
        throw new Error('Falha de rede (Failed to fetch) ao salvar Cotações. Verifique seu AdBlocker/Brave Shields.');
      }
      throw e;
    }

    // 3. Sync Feedback Logs (We use 'FollowUp' table to bypass adblockers targeting the word 'Feedback'/'Log')
    const mappedFeedbacks = feedbacks.map(f => ({
      id: f.id,
      quoteId: f.quoteId,
      note: f.note,
      createdBy: f.createdBy,
      createdAt: f.createdAt
    }));

    let activeFbTable = 'FollowUp';
    try {
      // Check which table name actually exists in Supabase to avoid exceptions
      const { error: checkErr } = await client.from('FollowUp').select('id').limit(1);
      if (checkErr && checkErr.message?.includes("Could not find the table 'public.FollowUp'")) {
        activeFbTable = 'FeedbackLog';
      }
    } catch {
      activeFbTable = 'FeedbackLog';
    }

    if (mappedFeedbacks.length > 0) {
      try {
        let { error: fbErr } = await client.from(activeFbTable).upsert(mappedFeedbacks);
        if (fbErr && activeFbTable === 'FollowUp' && fbErr.message?.includes("Could not find the table 'public.FollowUp'")) {
          activeFbTable = 'FeedbackLog';
          const { error: fbFallbackErr } = await client.from('FeedbackLog').upsert(mappedFeedbacks);
          if (fbFallbackErr) {
            throw new Error(`Falha ao sincronizar Acompanhamentos/Feedbacks no banco (tentado tabelas FollowUp e FeedbackLog): ${fbFallbackErr.message}`);
          }
        } else if (fbErr) {
          throw new Error(`Falha ao sincronizar Acompanhamentos/Feedbacks no banco: ${fbErr.message}`);
        }
      } catch (e: any) {
        if (e.message?.includes('Failed to fetch') || e.message?.includes('failed to fetch') || e instanceof TypeError) {
          throw new Error('Erro de Conectividade (Failed to fetch) na tabela de Feedbacks. IMPORTANTE: Seu navegador de internet ou extensão de privacidade (AdBlock, uBlock, Brave Shields) está bloqueando a comunicação com o Supabase. Por favor, desative o AdBlock para este site de CRM.');
        }
        throw e;
      }
    }

    // 4. Sync Insights
    const mappedInsights = insights.map(i => ({
      id: i.id,
      title: i.title,
      description: i.description,
      category: i.category,
      createdBy: i.createdBy,
      createdAt: i.createdAt
    }));

    if (mappedInsights.length > 0) {
      try {
        const { error: insErr } = await client.from('Insight').upsert(mappedInsights);
        if (insErr) throw new Error(`Falha ao sincronizar Insights/Ideias: ${insErr.message}`);
      } catch (e: any) {
        if (e.message?.includes('Failed to fetch') || e.message?.includes('failed to fetch')) {
          throw new Error('Falha de rede (Failed to fetch) ao salvar Insights. Desative seu AdBlocker.');
        }
        throw e;
      }
    }

    // 5. Automatic Deletion Synchronization: Find items that were deleted locally and delete them from Supabase
    try {
      // Step A: Determine which Quotes are being deleted
      const { data: serverQuotes, error: sQErr } = await client.from('Quote').select('id');
      if (sQErr) {
        console.warn('Não foi possível buscar cotações do servidor para limpeza de excluídas:', sQErr.message);
      } else {
        const serverQuotesIds = serverQuotes ? serverQuotes.map(x => x.id) : [];
        const localQuotesIds = quotes.map(x => x.id);
        const toDeleteQuotes = serverQuotesIds.filter(id => !localQuotesIds.includes(id));

        // Step B: Determine which Feedbacks / FollowUps are being deleted
        const { data: serverFeedbacks, error: sFBErr } = await client.from(activeFbTable).select('id, quoteId');
        if (sFBErr) {
          console.warn('Não foi possível buscar feedbacks do servidor para limpeza de excluídas:', sFBErr.message);
        } else {
          const serverFeedbacksIds = serverFeedbacks ? serverFeedbacks.map(x => x.id) : [];
          const localFeedbacksIds = feedbacks.map(x => x.id);
          
          const toDeleteFeedbacks = serverFeedbacks
            ? serverFeedbacks
                .filter(fb => !localFeedbacksIds.includes(fb.id) || toDeleteQuotes.includes(fb.quoteId))
                .map(fb => fb.id)
            : [];

          // Step C: Delete Feedbacks/FollowUps first (Cascade deletion manually)
          if (toDeleteFeedbacks.length > 0) {
            const { error: fDelErr } = await client.from(activeFbTable).delete().in('id', toDeleteFeedbacks);
            if (fDelErr) {
              console.warn(`Erro secundário ao remover feedbacks/followups (${activeFbTable}):`, fDelErr.message);
            }
          }
        }

        // Step D: Now delete the Parent Quotes
        if (toDeleteQuotes.length > 0) {
          const { error: qDelErr } = await client.from('Quote').delete().in('id', toDeleteQuotes);
          if (qDelErr) {
            console.warn('Erro secundário ao remover cotações do Supabase:', qDelErr.message);
          }
        }
      }

      // Step E: Sync Insight deletions
      const { data: serverInsights, error: sIErr } = await client.from('Insight').select('id');
      if (sIErr) {
        console.warn('Não foi possível buscar ideias/insights do servidor para limpeza de excluídas:', sIErr.message);
      } else {
        const serverInsightsIds = serverInsights ? serverInsights.map(x => x.id) : [];
        const localInsightsIds = insights.map(x => x.id);
        const toDeleteInsights = serverInsightsIds.filter(id => !localInsightsIds.includes(id));

        if (toDeleteInsights.length > 0) {
          const { error: iDelErr } = await client.from('Insight').delete().in('id', toDeleteInsights);
          if (iDelErr) {
            console.warn('Erro secundário ao remover ideias/insights do Supabase:', iDelErr.message);
          }
        }
      }
    } catch (delError: any) {
      console.warn('Aviso: Erro secundário durante a varredura preventiva de remoções:', delError);
      // We do NOT fail the main function anymore, so updates and additions are saved successfully!
    }

    return { 
      success: true, 
      quoteCount: quotes.length, 
      feedbackCount: feedbacks.length, 
      insightCount: insights.length, 
      message: 'Sincronização completa de ida realizada com sucesso!' 
    };
  } catch (err: any) {
    console.error('Supabase Sync error:', err);
    return { success: false, quoteCount: 0, feedbackCount: 0, insightCount: 0, message: err.message || 'Erro desconhecido.' };
  }
}

/**
 * Recovers all data from Supabase and allows replacing local cache 
 */
export async function pullDataFromSupabase(): Promise<{
  success: boolean;
  quotes: Quote[];
  feedbacks: FeedbackLog[];
  insights: Insight[];
  message: string;
}> {
  const client = getSupabaseClient();
  if (!client) {
    return { success: false, quotes: [], feedbacks: [], insights: [], message: 'Supabase não configurado.' };
  }

  try {
    // 1. Pull quotes
    const { data: quotesData, error: qErr } = await client.from('Quote').select('*');
    if (qErr) throw new Error(`Erro ao baixar Cotações: ${qErr.message}`);

    // 2. Pull feedbacks (We query 'FollowUp' table with automatic fallback to 'FeedbackLog' to ensure backward compatibility and bypass adblockers)
    let fbData = null;
    const { data: fbDataTry, error: fErr } = await client.from('FollowUp').select('*');
    if (fErr) {
      if (fErr.message?.includes("Could not find the table 'public.FollowUp'")) {
        const { data: fbFallbackData, error: fbFallbackErr } = await client.from('FeedbackLog').select('*');
        if (fbFallbackErr) {
          throw new Error(`Erro ao baixar Coleção de Feedbacks (tentado FollowUp e FeedbackLog): ${fbFallbackErr.message}`);
        }
        fbData = fbFallbackData;
      } else {
        throw new Error(`Erro ao baixar Coleção de Feedbacks (FollowUp): ${fErr.message}`);
      }
    } else {
      fbData = fbDataTry;
    }

    // 3. Pull insights
    const { data: insData, error: iErr } = await client.from('Insight').select('*');
    if (iErr) throw new Error(`Erro ao baixar Insights: ${iErr.message}`);

    const quotes: Quote[] = (quotesData || []).map(q => ({
      id: q.id,
      clientName: q.clientName,
      projectName: q.projectName,
      contactPhone: q.contactPhone,
      contactEmail: q.contactEmail || '',
      description: q.description || '',
      value: Number(q.value) || 0,
      margin: Number(q.margin) || 0,
      estimatedDate: q.estimatedDate ? q.estimatedDate.split('T')[0] : '',
      status: q.status,
      priority: q.priority,
      responsibleId: q.responsibleId,
      lossReason: q.lossReason,
      lossDetails: q.lossDetails,
      supplierLinks: q.supplierLinks || [],
      productPhotos: q.productPhotos || [],
      technicalProposal: q.technicalProposal || '',
      commercialProposal: q.commercialProposal || '',
      createdAt: q.createdAt,
      updatedAt: q.updatedAt
    }));

    const feedbacks: FeedbackLog[] = (fbData || []).map(f => ({
      id: f.id,
      quoteId: f.quoteId,
      note: f.note,
      createdBy: f.createdBy,
      createdAt: f.createdAt
    }));

    const insights: Insight[] = (insData || []).map(ins => ({
      id: ins.id,
      title: ins.title,
      description: ins.description,
      category: ins.category,
      createdBy: ins.createdBy,
      createdAt: ins.createdAt
    }));

    return {
      success: true,
      quotes,
      feedbacks,
      insights,
      message: `Dados puxados da nuvem! Sincronizados ${quotes.length} cotações, ${feedbacks.length} feedbacks e ${insights.length} ideias.`
    };
  } catch (err: any) {
    console.error('Supabase pull error:', err);
    return { success: false, quotes: [], feedbacks: [], insights: [], message: err.message || 'Erro desconhecido.' };
  }
}

/**
 * Deletes a single Quote and its child feedback logs from Supabase
 */
export async function deleteQuoteFromSupabase(id: string): Promise<{ success: boolean; message: string }> {
  const client = getSupabaseClient();
  if (!client) {
    return { success: false, message: 'Supabase não configurado.' };
  }

  try {
    let activeFbTable = 'FollowUp';
    try {
      const { error: checkErr } = await client.from('FollowUp').select('id').limit(1);
      if (checkErr && (checkErr.message?.includes("Could not find the table") || checkErr.message?.includes("relation"))) {
        activeFbTable = 'FeedbackLog';
      }
    } catch {
      activeFbTable = 'FeedbackLog';
    }

    // 1. Delete feedback logs first
    const { error: fbErr } = await client.from(activeFbTable).delete().eq('quoteId', id);
    if (fbErr) {
      console.warn('Erro ao limpar feedbacks da cotação no servidor, mas continuando exclusão:', fbErr.message);
    }

    // 2. Delete the Quote
    const { error: qErr } = await client.from('Quote').delete().eq('id', id);
    if (qErr) {
      throw new Error(`Erro ao excluir cotação na nuvem: ${qErr.message}`);
    }

    return { success: true, message: 'Cotação excluída com sucesso na nuvem.' };
  } catch (err: any) {
    console.error('Erro na exclusão direta de cotação:', err);
    return { success: false, message: err.message || 'Erro desconhecido.' };
  }
}

/**
 * Deletes a single Feedback (Follow-up) from Supabase
 */
export async function deleteFeedbackFromSupabase(id: string): Promise<{ success: boolean; message: string }> {
  const client = getSupabaseClient();
  if (!client) {
    return { success: false, message: 'Supabase não configurado.' };
  }

  try {
    let activeFbTable = 'FollowUp';
    try {
      const { error: checkErr } = await client.from('FollowUp').select('id').limit(1);
      if (checkErr && (checkErr.message?.includes("Could not find the table") || checkErr.message?.includes("relation"))) {
        activeFbTable = 'FeedbackLog';
      }
    } catch {
      activeFbTable = 'FeedbackLog';
    }

    const { error } = await client.from(activeFbTable).delete().eq('id', id);
    if (error) {
      throw new Error(`Erro ao excluir feedback na nuvem: ${error.message}`);
    }

    return { success: true, message: 'Feedback excluído com sucesso.' };
  } catch (err: any) {
    console.error('Erro na exclusão direta de feedback:', err);
    return { success: false, message: err.message || 'Erro desconhecido.' };
  }
}

/**
 * Deletes a single Insight from Supabase
 */
export async function deleteInsightFromSupabase(id: string): Promise<{ success: boolean; message: string }> {
  const client = getSupabaseClient();
  if (!client) {
    return { success: false, message: 'Supabase não configurado.' };
  }

  try {
    const { error } = await client.from('Insight').delete().eq('id', id);
    if (error) {
      throw new Error(`Erro ao excluir insight na nuvem: ${error.message}`);
    }

    return { success: true, message: 'Insight excluído com sucesso.' };
  } catch (err: any) {
    console.error('Erro na exclusão direta de insight:', err);
    return { success: false, message: err.message || 'Erro desconhecido.' };
  }
}

