/**
 * Geração de Proposta Técnica + Comercial (Metrolabs).
 * - Usa Gemini 2.5 Flash (free tier, sem cartão) via @google/genai.
 * - Puxa a foto do produto do link (og:image) ou descreve a página.
 * - Armazena logo/fotos no Supabase Storage (bucket 'proposals').
 */

import { GoogleGenAI } from '@google/genai';
import { getSupabaseClient } from './supabase';
import { CompanyProfile, Quote, QuoteItem } from '../types';

// Template de ficha técnica padrão (editável em localStorage)
const DEFAULT_TECHNICAL_PROMPT = `Você é o comercial da METROLABS. A partir dos dados da cotação e dos links de fornecedor,
gere DUAS seções claras e profissionais em português:

[PROPOSTA TÉCNICA]
- Itens extraídos dos fornecedores (nome, especificações, tensão/potência/normas se aplicável)
- Material incluso e não incluso
- Prazo de execução/entrega

[PROPOSTA COMERCIAL]
- Investimento total e condição de pagamento sugerida
- Garantia e diferencial Metrolabs
- Próximo passo para fechamento

Seja conciso, padronizado e pronto para PDF timbrado.`;

export function getProposalPrompt(): string {
  try {
    const stored = localStorage.getItem('metrolabs-proposal-prompt');
    if (stored) return stored;
  } catch {
    /* ignore */
  }
  return DEFAULT_TECHNICAL_PROMPT;
}

export function saveProposalPrompt(p: string) {
  localStorage.setItem('metrolabs-proposal-prompt', p);
}

// Extrai og:image de uma página de produto (ML / site de empresa)
export async function extractProductPhoto(link: string): Promise<string> {
  try {
    const res = await fetch(link, { method: 'GET' });
    const html = await res.text();
    const match = html.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i)
      || html.match(/<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:image["']/i);
    if (match && match[1]) return match[1];
  } catch {
    /* ignore */
  }
  return '';
}

// Faz upload de um Blob/File para o bucket 'proposals' no Supabase Storage
export async function uploadProposalImage(
  file: Blob,
  path: string
): Promise<string | null> {
  const client = getSupabaseClient();
  if (!client) return null;
  try {
    const { error } = await client.storage
      .from('proposals')
      .upload(path, file, { upsert: true, contentType: file.type || 'image/png' });
    if (error) {
      console.error('Erro upload Storage:', error.message);
      return null;
    }
    const { data } = client.storage.from('proposals').getPublicUrl(path);
    return data.publicUrl;
  } catch (e) {
    console.error('Falha upload:', e);
    return null;
  }
}

// Gera o texto da proposta via Gemini 2.5 Flash (free tier)
export async function generateProposal(
  quote: Quote,
  items: QuoteItem[],
  company: CompanyProfile,
  apiKey: string
): Promise<{ technicalProposal: string; commercialProposal: string }> {
  const ai = new GoogleGenAI({ apiKey });

  const links = items.map((i) => i.supplierLink).filter(Boolean).join('\n');
  const prompt = `
${getProposalPrompt()}

EMPRESA: ${company.razaoSocial} (${company.fantasia})
CNPJ: ${company.cnpj}
CLIENTE: ${quote.clientName}
PROJETO: ${quote.projectName}
DESCRIÇÃO: ${quote.description}
VALOR COTADO: R$ ${quote.value}  (margem ${quote.margin}%)
PRAZO: ${quote.estimatedDate || 'a combinar'}

LINKS DE FORNECEDOR:
${links || '(nenhum link informado)'}
`;

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: prompt,
  });

  const text = response.text || '';
  const techMatch = text.match(/\[PROPOSTA TÉCNICA\]([\s\S]*?)(\[PROPOSTA COMERCIAL\]|$)/i);
  const comMatch = text.match(/\[PROPOSTA COMERCIAL\]([\s\S]*)/i);

  return {
    technicalProposal: (techMatch?.[1] || text).trim(),
    commercialProposal: (comMatch?.[1] || '').trim(),
  };
}
