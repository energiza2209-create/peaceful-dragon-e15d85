/**
 * Gera PDF timbrado da METROLABS (cabeçalho institucional + fotos + propostas).
 * Usa jsPDF. Logo e fotos vêm do Supabase Storage (URLs públicas).
 */

import { jsPDF } from 'jspdf';
import { CompanyProfile, Quote, QuoteItem } from '../types';

function wrapText(doc: jsPDF, text: string, x: number, y: number, maxWidth: number, lineHeight: number): number {
  const lines = doc.splitTextToSize(text, maxWidth);
  doc.text(lines, x, y);
  return y + lines.length * lineHeight;
}

export async function generateProposalPdf(
  company: CompanyProfile,
  quote: Quote,
  items: QuoteItem[],
  technicalProposal: string,
  commercialProposal: string
): Promise<void> {
  const doc = new jsPDF({ unit: 'pt', format: 'a4' });
  const pageW = doc.internal.pageSize.getWidth();
  const margin = 40;
  const contentW = pageW - margin * 2;

  // ---- CABEÇALHO TIMBRADO METROLABS ----
  let y = margin;
  if (company.logoUrl) {
    try {
      const img = await loadImage(company.logoUrl);
      const logoH = 50;
      const logoW = (img.width / img.height) * logoH;
      doc.addImage(img, 'PNG', margin, y, Math.min(logoW, 160), logoH);
    } catch {
      /* logo opcional */
    }
  }

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.text(company.razaoSocial, margin, y + 70);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  let headerY = y + 84;
  const headerLines = [
    `Fantasia: ${company.fantasia}`,
    `CNPJ: ${company.cnpj}  |  IE: ${company.inscricaoEstadual}  |  IM: ${company.inscricaoMunicipal}`,
    `Endereço: ${company.endereco} - CEP ${company.cep} - Goiânia/GO`,
    `Contato: ${company.telefone}  |  ${company.email}`,
    company.bankInfo,
  ];
  headerLines.forEach((l) => {
    doc.text(doc.splitTextToSize(l, contentW), margin, headerY);
    headerY += 12;
  });

  // linha divisória
  doc.setDrawColor(200);
  doc.line(margin, headerY + 4, pageW - margin, headerY + 4);
  y = headerY + 20;

  // ---- TÍTULO DA PROPOSTA ----
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.text(`PROPOSTA TÉCNICA E COMERCIAL — ${quote.projectName || 'Sem título'}`, margin, y);
  y += 18;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  y = wrapText(doc, `Cliente: ${quote.clientName}`, margin, y, contentW, 14);
  y = wrapText(doc, `Responsável comercial: ${company.responsavel}`, margin, y, contentW, 14);
  y = wrapText(doc, `Investimento: R$ ${quote.value}  (margem ${quote.margin}%)`, margin, y, contentW, 14);
  y = wrapText(doc, `Prazo: ${quote.estimatedDate || 'a combinar'}`, margin, y, contentW, 14);
  y += 8;

  // ---- FOTOS DOS PRODUTOS ----
  const photos = items.map((i) => i.productPhoto).filter(Boolean);
  if (photos.length > 0) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.text('Produtos Ofertados', margin, y);
    y += 10;
    let xPos = margin;
    for (const url of photos) {
      try {
        const img = await loadImage(url);
        const h = 90;
        const w = (img.width / img.height) * h;
        if (xPos + w > pageW - margin) {
          xPos = margin;
          y += h + 10;
        }
        doc.addImage(img, 'PNG', xPos, y, w, h);
        xPos += w + 10;
      } catch {
        /* pula imagem quebrada */
      }
    }
    y += 100;
  }

  // ---- PROPOSTA TÉCNICA ----
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text('PROPOSTA TÉCNICA', margin, y);
  y += 16;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  y = wrapText(doc, technicalProposal || 'Não gerada.', margin, y, contentW, 13);
  y += 12;

  // ---- PROPOSTA COMERCIAL ----
  if (commercialProposal) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12);
    doc.text('PROPOSTA COMERCIAL', margin, y);
    y += 16;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    y = wrapText(doc, commercialProposal, margin, y, contentW, 13);
    y += 12;
  }

  // ---- RODAPÉ GARANTIA ----
  if (company.garantia) {
    doc.setFont('helvetica', 'italic');
    doc.setFontSize(9);
    wrapText(doc, company.garantia, margin, y + 8, contentW, 12);
  }

  doc.save(`Proposta_Metrolabs_${quote.projectName || quote.id}.pdf`);
}

function loadImage(url: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = url;
  });
}
