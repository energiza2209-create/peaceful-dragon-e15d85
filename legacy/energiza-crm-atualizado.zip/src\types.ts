/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Priority = 'high' | 'medium' | 'low';

export type QuoteStatus = 
  | 'new'          // Nova Cotação / Triagem
  | 'analysis'     // Em Análise / Elaboração
  | 'sent'         // Enviada / Aguardando Resposta
  | 'negotiation'  // Negociação / Ajustes
  | 'won'          // Ganha (Sucesso)
  | 'lost';        // Perdida / Cancelada

export type InsightCategory = 'improvement' | 'nicho' | 'supplier'| 'other';

export interface User {
  id: string;
  name: string;
  avatar: string;
  role: 'eu' | 'ela';
}

export interface Quote {
  id: string;
  clientName: string;
  projectName: string;
  contactPhone: string; // WhatsApp
  contactEmail: string;
  description: string;
  value: number;
  margin: number;       // Margem de lucro estimada (%)
  estimatedDate: string; // Prazo de entrega
  createdAt: string;
  updatedAt: string;
  status: QuoteStatus;
  priority: Priority;
  responsibleId: string; // ID of the User
  lossReason?: 'price' | 'deadline' | 'competitor' | 'vanished' | 'other';
  lossDetails?: string;
  supplierLinks?: string[];     // Links de fornecedores (ML / sites)
  productPhotos?: string[];     // URLs das fotos (Storage)
  technicalProposal?: string;    // Proposta técnica gerada
  commercialProposal?: string;  // Proposta comercial gerada
}

export interface FeedbackLog {
  id: string;
  quoteId: string;
  note: string;
  createdBy: string; // User Name or ID
  createdAt: string;
}

export interface Insight {
  id: string;
  title: string;
  description: string;
  category: InsightCategory;
  createdBy: string; // User Name or ID
  createdAt: string;
  convertedToQuoteId?: string; // If this insight became a quote
}

// Columns configuration structure
export interface KanbanColumn {
  id: QuoteStatus;
  title: string;
  color: string; // Tailwind border/bg indicator color
}

// Company profile (papel timbrado / cabeçalho institucional)
export interface CompanyProfile {
  razaoSocial: string;
  fantasia: string;
  cnpj: string;
  inscricaoEstadual: string;
  inscricaoMunicipal: string;
  endereco: string;
  cep: string;
  email: string;
  telefone: string;
  logoUrl: string;        // Storage (Supabase)
  bankInfo: string;       // Dados para pagamento
  garantia: string;       // Texto de garantia/diferencial fixo
  responsavel: string;    // Responsável comercial
}

// Supplier link + foto extraída/upada para a proposta técnica
export interface QuoteItem {
  supplierLink: string;
  productPhoto: string;   // URL da foto (Storage) ou vazia
  technicalText: string;  // ficha técnica gerada/Editável
}

// Proposal generated (técnica + comercial) attached to a Quote
export interface Proposal {
  id: string;
  quoteId: string;
  items: QuoteItem[];
  technicalProposal: string;   // texto consolidado da proposta técnica
  commercialProposal: string;  // texto consolidado da proposta comercial
  createdAt: string;
  updatedAt: string;
}
