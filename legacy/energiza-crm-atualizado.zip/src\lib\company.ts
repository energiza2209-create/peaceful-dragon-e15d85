/**
 * Perfil institucional METROLABS — papel timbrado usado nas propostas.
 * Dados reais fornecidos por Matheus (comercial da Metrolabs).
 * A logo e fotos de produto são armazenadas no Supabase Storage (bucket 'proposals').
 */

import { CompanyProfile } from '../types';

export const METROLABS_PROFILE: CompanyProfile = {
  razaoSocial: 'METROLAB SOLUÇÕES EM ENGENHARIA CLINICA LTDA',
  fantasia: "METROLAB'S SOLUÇÕES EM ENGENHARIA CLÍNICA",
  cnpj: '32.487.278/0001-21',
  inscricaoEstadual: '10.781.375-0',
  inscricaoMunicipal: '4743504',
  endereco: 'RUA C 155, Nº 789, QUADRA 365, LOTE 08, JARDIM AMÉRICA',
  cep: '74.275-150',
  email: 'ADMINISTRATIVO@METROLABS.COM.BR',
  telefone: '(62) 3123-1595',
  logoUrl: '', // preencher com URL do Storage após upload
  bankInfo:
    'Dados bancários Metrolabs disponíveis mediante fechamento.\n' +
    'Pagamento: entrar em contato com Financeiro (Wanessa) - (62) 3123-1595.',
  garantia:
    'Garantia e acompanhamento técnico Metrolabs. Optante do Simples Nacional.',
  responsavel: 'Matheus — Comercial Metrolabs',
};

// Carrega perfil do localStorage (permite editar timbre sem rede) com fallback Metrolabs
export function getCompanyProfile(): CompanyProfile {
  try {
    const stored = localStorage.getItem('metrolabs-profile');
    if (stored) return JSON.parse(stored) as CompanyProfile;
  } catch {
    /* ignore */
  }
  return METROLABS_PROFILE;
}

export function saveCompanyProfile(p: CompanyProfile) {
  localStorage.setItem('metrolabs-profile', JSON.stringify(p));
}
